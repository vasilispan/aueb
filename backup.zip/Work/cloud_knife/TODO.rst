

TODO list
=========

- Take care of README and add feature list.
- sample todo item


