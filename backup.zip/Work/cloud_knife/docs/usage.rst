=====
Usage
=====

To use Cloud Knife in a project::

    import cloud_knife
