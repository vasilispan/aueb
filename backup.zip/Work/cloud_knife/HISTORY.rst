.. :changelog:

=======
History
=======

0.0.1 (2017-02-23)
------------------

* First release on internal PyPI.
