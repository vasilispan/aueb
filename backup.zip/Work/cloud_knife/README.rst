===============================
Cloud Knife
===============================

.. image:: https://img.shields.io/pypi/v/cloud_knife.svg
        :target: https://pypi.python.org/pypi/cloud_knife


.. image:: https://readthedocs.org/projects/cloud_knife/badge/?version=latest
        :target: https://readthedocs.org/projects/cloud_knife/?badge=latest
        :alt: Documentation Status


 Cloud multitool

* Free software: ISC license

Features
--------

* Create an instance and associate a new volume to it

Installing
----------

* sudo python setup.py install
* sudo python setup.py install_egg_info

Running
-------

* To create a RHEL7.3 node you can run: python cloud_knife/cloud_knife.py --user_id <intra_user_id> --user_email <your_email> --instance_size m1.small --instance_image rhel73

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
