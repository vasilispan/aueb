#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_cloud_knife
----------------------------------

Tests for `cloud_knife` module.
"""

import pytest


from cloud_knife import cloud_knife

class TestCloud_knife(object):

    @classmethod
    def setup_class(cls):
        pass

    def test_something(self):
        pass

    @classmethod
    def teardown_class(cls):
        pass

