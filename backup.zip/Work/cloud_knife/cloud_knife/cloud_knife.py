#!/usr/bin/env python

from pprint import pprint
from ec2config import EC2Config as configuration
import argparse
import sys

class CloudKnife:

    def __init__(self,args):
        self.arguments = args
        self.az = 'esclor86_4'
        self.ec2driver = configuration().ec2driver
        self.myimage = configuration().getimageid(self.arguments.instance_image)
        configuration().getexistinginstance(self.arguments.user_id)

    def run(self):
        ''' setup ec2 driver and get arguments'''
        print('Run')
        image_size,machine_image,avail = self.getarguments()
        print("Deploying {} \'{}\' in {}".format(image_size.name,self.arguments.user_id,avail[0].name))
        new_node = self.ec2driver.create_node(name=self.arguments.user_id,
                                               image=machine_image,size=image_size,
                                               ex_keyname='pmod-base',location=str(avail))
        # user_instance,ipaddress = self.ec2driver.wait_until_running([new_node])[0]
        # user_volume = self.createvolume(user_instance)
        # self.attachvolume(user_instance,user_volume)
        # print("\nNew node {}:{} has address {} and volume attached {}\n".format(user_instance.name,
        #                                                  user_instance.id,ipaddress[0],user_volume.id))

    def getarguments(self):
        mysize = [s for s in self.ec2driver.list_sizes() if s.id == self.arguments.instance_size][0]
        machineimage = [d for d in self.ec2driver.list_images() if d.id == self.myimage][0]
        location = [d for d in self.ec2driver.list_locations() if d.name == self.az]#[0]
        return (mysize,machineimage,location)

    def createvolume(self,node):
        ''' creates a volume and mounts on the instance (still needs partition table and mkfs.ext4'''
        volume_loc = [d for d in self.ec2driver.list_locations() if d.name == node.extra['availability']][0]
        newvol = self.ec2driver.create_volume(size=10,name=self.arguments.user_id,
                                              ex_volume_type='standard',location=volume_loc)
        return newvol

    def attachvolume(self,node,volume):
        self.ec2driver.attach_volume(node,volume,'/dev/vdc')

def parse(args):
    ''' parse input args'''
    parser = argparse.ArgumentParser()
    parser.add_argument("--user_id",help="the name of the instance")
    parser.add_argument("--user_email",help="email of user")
    parser.add_argument("--instance_size",help="the size of the instance")
    parser.add_argument("--instance_image",help="the image id of the instance")
    args=parser.parse_args()
    return args

def main(input_args):
    args = parse(input_args)
    pprint(args)
    CloudKnife(args).run()

if __name__ == "__main__":
    main(sys.argv[1:])
