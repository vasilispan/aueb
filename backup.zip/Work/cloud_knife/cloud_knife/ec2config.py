import os
import sys
from libcloud.compute.types import Provider
from libcloud.compute.providers import get_driver
from pprint import pprint

class EC2Config:
    EC2_ACCESS_ID = 'AKIAAXMZEPKJFPT5EYSP'
    EC2_SECRET_KEY = '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'

    def __init__(self):
        # driver = ''
        self.imagesDict = {}
        self.ec2driver=self.setupec2driver()

    def setupec2driver(self):
        EC2Driver = get_driver(Provider.EC2)
        self.driver = EC2Driver(self.EC2_ACCESS_ID, self.EC2_SECRET_KEY, region='eucalyptus', port=8773,
                           secure=False)
        return self.driver

    def get_dict(self):
        self.imagesDict['vtasRHEL'] = 'emi-cb90864c'
        self.imagesDict['fedora25'] = 'emi-9d46a1b2 '
        self.imagesDict['fedora25preinstalled'] = 'emi-1b1b1cdb'
        self.imagesDict['fedora24'] = 'emi-ecf6459b'
        self.imagesDict['fedora25preinstalled'] = 'emi-b951f5d9'
        self.imagesDict['rhel73'] = 'emi-78ab673f'
        self.imagesDict['centos73'] = 'emi-c8191185'
        return self.imagesDict

    def getimageid(self,imagename):
        '''returns '''
        if self.get_dict().has_key(imagename):
            return self.get_dict()[imagename]
        else:
            sys.exit("Invalid image. Please use a supported image from \n{}".format(self.imagesDict.keys()))

    def getassociatedvolume(self,instance):
        '''returns True if there are no associated volumes'''
        data = instance[0].extra
        #pprint(data)
        if data and data.has_key('block_device_mapping'):
            if (data['block_device_mapping'][0]['ebs']['volume_id']) is not None:
                return data['block_device_mapping'][0]['ebs']['volume_id']
            else:
                return "null"
        else:
            return True

    def getexistinginstance(self,user):
        ''' returns True if there is no running user instance'''
        nodes = self.ec2driver.list_nodes()
        existing = [i for i in self.ec2driver.list_nodes() if (i.name == user and i.state == 'running')]
        #pprint(existing)
        if existing:
            existing_volume = self.getassociatedvolume(existing)
            sys.exit("found instance {} and volume {}".format(existing.id,existing_volume))
        elif not existing:
            return True
