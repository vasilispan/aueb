import os
import string
import shutil
import errno
import mmap
import imp
from sys import exit as exit

class PatchDriver:

	def __init__(self):
		print("Initialized patchdriver")

	def copyfile(self,file):
		''' copy file to ~/.libcloud from ../files'''
		libcloudconfig = os.path.join(os.environ["HOME"], ".libcloud/")
		if os.path.exists(libcloudconfig):
			if os.path.isfile(os.path.join(libcloudconfig, file)):
				print("all good with {}".format(file))
			else:
				print("Copying file {}".format(file))
				shutil.copy(file,libcloudconfig)
		else:	# PATH AND FILE DO NOT EXIST
			os.makedirs(libcloudconfig)
			shutil.copy(file, libcloudconfig)

	def patch(self,file, text, after=None):
		''' Prepend file with given raw text '''
		self.verifyfile(file)
		with open(file, 'r') as input:
			buff = input.read()
			s = mmap.mmap(input.fileno(),0,access=mmap.ACCESS_READ)
			if s.find(text) ==1 :
				return True
		with open(file, 'w+') as final:
			inject_pos = 0  # pointer to line that contains 'after' variable
			if after:
				pattern = after
				inject_pos = buff.find(pattern)+len(pattern)
				final.write(buff[:inject_pos] + str(text) + buff[inject_pos:])
				final.close()
			return True

	def getlines(self,content):
		''' returns the contents of a file in string format'''
		with open(content,'r') as f:
			text = ''
			for line in f :
				text+=line
			return '\n'+ text

	def verifyfile(self,file):
		''' verify if a file exists '''
		if os.path.exists(file):
			print('Found {}, patching...'.format(file))
			return True
		else:
			exit("Please install apache-libcloud")

	def find_module(self,name, path=None):
		''' find the path of a module'''
		res = None
		for x in name.split('.'):
			res = imp.find_module(x, path)
			path = [res[1]]
		return res[1]

	def replacelines(self,file,old,new):
		self.verifyfile(file)
		#old = "\'region-name\': self.region_name"
		with open(file) as f:
			contents = f.read()
			if old not in contents:
				print("No need to patch {}".format(str(file)))
				return
		with open(file,'w') as f:
			contents=contents.replace(old , new)
			f.write(contents)
