# -*- coding: utf-8 -*-

__author__ = 'Lianos Chrysanthos'
__email__ = 'chrysanthos.lianos@nokia.com'
__version__ = '0.0.1'
