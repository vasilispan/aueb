#!/usr/bin/env python
# -*- coding: utf-8 -*-

from cloud_knife import patchdriver
import site
import os
import pip
from pip.req import parse_requirements
import sys
from setuptools.command.test import test as TestCommand

class PyTest(TestCommand):
    user_options = [('pytest-args=', 'a', "Arguments to pass to py.test")]

    def initialize_options(self):
        TestCommand.initialize_options(self)
        self.pytest_args = []

    def run_tests(self):
        # import here, cause outside the eggs aren't loaded
        import pytest
        errno = pytest.main(self.pytest_args)
        sys.exit(errno)

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup


with open('README.rst') as readme_file:
    readme = readme_file.read()

with open('HISTORY.rst') as history_file:
    history = history_file.read().replace('.. :changelog:', '')

parsed_requirements = parse_requirements(
    'requirements/prod.txt',
    session=pip.download.PipSession()
)

parsed_test_requirements = parse_requirements(
    'requirements/test.txt',
    session=pip.download.PipSession()
)


requirements = [str(ir.req) for ir in parsed_requirements]
test_requirements = [str(tr.req) for tr in parsed_test_requirements]

setup(
    setup_cfg=True, 
    name='cloud_knife',
    version='0.0.1',
    description=" Cloud multitool",
    long_description=readme + '\n\n' + history,
    author="Lianos Chrysanthos",
    author_email='chrysanthos.lianos@nokia.com',
    url='https://gitlabe1.ext.net.nokia.com/ntas_ath_scmci/cloud_knife',
    packages=[
        'cloud_knife',
    ],
    package_dir={'cloud_knife':
                 'cloud_knife'},
    include_package_data=True,
    install_requires=['apache-libcloud==1.5.0'],
    #    install_requires=requirements,
    license="ISCL",
    zip_safe=False,
    keywords='cloud_knife',
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: ISC License (ISCL)',
        'Natural Language :: English',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3',
	    'Programming Language :: Python :: 3.5',
    ],
    test_suite='tests',
    tests_require=test_requirements,
    cmdclass = {'test': PyTest, 'pytest': PyTest},
)
print("Patching libcloud EC2 driver")
patcher = patchdriver.PatchDriver()
patcher.copyfile('files/pricing.json')
ec2driver = patcher.find_module('libcloud.compute.drivers.ec2')
patcher.patch(ec2driver,patcher.getlines('files/regions'), 'REGION_DETAILS = {')
patcher.replacelines(ec2driver,"\'region-name\': self.region_name","\t")
print("Setup finished")
