#!/usr/bin/python

from subprocess import check_output,call
import argparse, sys


def _get_tenants():
    tenants=['admin']
    out = check_output(['keystone', 'tenant-list'])
    for line in out.split('\n'):
        if 'Tenant' in line :
            tenants.append(line.split()[3])
    return tenants

def _get_users():
    users= ['admin']
    passwords= ['admin_pass']
    out = check_output(['keystone', 'user-list'])
    for line in out.split('\n'):
        if 'User' in line :
            users.append(line.split()[3])
            passwords.append('tenant_pass')
    return users, passwords

def _get_stack_list(users, tenants, passwords):
    stack_id_list = {}
    stack_name_list = {}

    for data in zip(users, tenants, passwords):
        try:
            out = check_output(['heat', '--os-username', data[0], '--os-tenant-name', data[1], '--os-password', data[2], 'stack-list']).split('\n')[3::2]
            for line in out:
                if line != '':
                    stack_name_list.setdefault(line.split()[3], data)
                    stack_id_list.setdefault(line.split()[1], data)
        except:
            continue 
    return stack_name_list, stack_id_list

def _get_stack_data(users, tenants, passwords, stack):
    stack_name_list, stack_id_list = _get_stack_list(users, tenants, passwords)
    if stack in stack_name_list:
        [user, tenant, password] = stack_name_list.get(stack)
        for _id,data in stack_id_list.items():
            if data == (user, tenant, password):
                stack_id = _id
                break
        else:
            return 'No such stack available'
    elif stack in stack_id_list:
        [user, tenant, password] = stack_id_list.get(stack)
        stack_id = stack
    else:
        return 'No such stack available'
    return stack_id, user, tenant, password


def  list_stacks(users, tenants, passwords):
    for idx,data in enumerate(zip(users, tenants, passwords)):
        try:
            print ''
            print '  User:  \t{0}'.format(data[0])
            print '  Tenant:\t{0}'.format(data[1])
            rtn = call(['heat', '--os-username', data[0], '--os-tenant-name', data[1], '--os-password', data[2], 'stack-list'])
        except :
            print 'Someone possibly deleted a user and/or tenant'

def delete_stack(users, tenants, passwords, stack_name):
    stack_id, user, tenant, password = _get_stack_data(users, tenants, passwords, stack_name)

    out = check_output(['cinder', '--os-username', user, '--os-tenant-name', tenant, '--os-password', password, 'list']).split('\n')
    ids=[]
    for line in out:
        if stack_name in line:
            ids.append(line.split()[1])
    for _id in ids:
        print 'deleting cinder volume with id: {0}'.format(_id)
        call(['cinder', 'force-delete', _id])
    
    call(['heat', '--os-username', user, '--os-tenant-name', tenant, '--os-password', password, 'stack-delete', stack_id])


def connect(users, tenants, passwords, stack_name, node='CLA-0'):
    stack_id, user, tenant, password = _get_stack_data(users, tenants, passwords, stack_name)

    out = check_output(['heat', '--os-username', user, '--os-tenant-name', tenant, '--os-password', password, 'resource-show', stack_id, node]).split('\n')
    for line in out:
        if 'physical_resource_id' in line:
            physical_resource_id = line.split()[3]

    out = check_output(['nova', '--os-username', user, '--os-tenant-name', tenant, '--os-password', password, 'interface-list', physical_resource_id]).split('\n')
    for line in out:
        if '192.168' in line:
            net_id = line.split()[5]
            ip_addr = line.split()[7]
    call(['ip', 'netns', 'exec', 'qdhcp-{0}'.format(net_id), 'ssh', 'root@{0}'.format(ip_addr)])

def main(argv):
    parser = argparse.ArgumentParser(description="list, connect or delete stacks")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-l', '--list', action="store_true")
    group.add_argument('-c', '--connect', nargs=2,metavar=('STACK_NAME','NODE'))
    group.add_argument('-d', '--delete', metavar='STACK_NAME')
    args = parser.parse_args()

    users, passwords = _get_users()
    if args.list:
        list_stacks(users, _get_tenants(), passwords)
    elif args.connect:
        connect(users, _get_tenants(), passwords, args.connect[0], args.connect[1])
    elif args.delete:
        delete_stack(users, _get_tenants(), passwords, args.delete)

if __name__ == '__main__':
    main(sys.argv)
