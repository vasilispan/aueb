#!/bin/bash

echo "Preparing to attach the NE3S management port to CLA-0 of stack ".$1
stack_name=$1

#get CLA ID
claid=$(heat resource-show $stack_name CLA-0 | grep physical_resource_id | cut -d '|' -f 3)
echo "cla id is ".$claid
#get subnet
#subnet=$(neutron subnet-list | grep $stack_name | grep management | cut -d '|' -f 2)

#get port
port=$( neutron port-list | grep $stack_name |  grep NE3S_management_port | cut -d '|' -f 2)
echo "port id is ".$port

#attach port to cla-0 ID
nova interface-attach --port-id $port  $claid
