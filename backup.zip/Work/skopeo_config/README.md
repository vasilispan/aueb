First you need to download go lang and setup GOPATH env var
Installation: sh installsteps.sh
After it is done go to $GOPATH/src/github.com/projectatomic/skopeo and you can execute skopeo binary, such as: 

./skopeo --tls-verify=false --debug inspect docker://utas-change-registry.dynamic.nsn-net.net:5000/opentas/webui > webui.json