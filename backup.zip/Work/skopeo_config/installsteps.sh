#!/bin/bash

gopath=$(env | grep GOPATH | cut -d '=' -f2)
if [  -z $gopath ]
	then
		echo "GOPATH env var not set,please set it: export GOPATH=~/go"
		exit
	else
		echo "GOPATH is set: $gopath . \nSetup..."
fi
skopeodir=$gopath/src/github.com/projectatomic/skopeo

git clone https://github.com/projectatomic/skopeo.git $skopeodir
cp $(pwd)/Dockerfile.utas.build $skopeodir/Dockerfile.build
cp $(pwd)/utas-change-registry-policy.json $skopeodir/default-policy.json

cd $skopeodir 
#echo 'ENV http_proxy http://10.159.43.88:8080 \nENV https_proxy http://10.159.43.88:8080' >> Dockerfile.build
make all
#cp $(pwd)/utas-change-registry-policy.json $skopeodir/default-policy.json
if [ $? = 0 ]
	then
		echo "Read the manual with 'man -l docs/skopeo.1"
fi
