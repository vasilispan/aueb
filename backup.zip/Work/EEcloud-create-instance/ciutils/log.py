import logging
import logging.config
import os

def _is_set_in_env(key):
    return os.environ.get(key) in ['true', 'True', 'TRUE']


class InfoFilter(logging.Filter):
    def filter(self, record):
        return record.levelno <= logging.INFO


class LogConfig(object):

    @classmethod
    def initialize(cls):
        if _is_set_in_env('DEBUG'):
            console_formatter = 'detailed'
            console_logging_level = 'DEBUG'
        else:
            console_formatter = 'simple'
            console_logging_level = 'INFO'
        logging.config.dictConfig({
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                    'simple': {
                        'format': '[%(levelname)s] %(message)s'
                    },
                    'detailed': {
                        'format': '%(asctime)s [%(levelname)s] %(pathname)s@%(lineno)d: %(message)s'
                    },
            },
            'filters': {
                'infofilter': {
                    '()': InfoFilter,
                },
            },
            'handlers': {
                'stdout': {
                    'class': 'logging.StreamHandler',
                    'level': console_logging_level,
                    'formatter': console_formatter,
                    'stream': 'ext://sys.stdout',
                    'filters': ['infofilter']
                },
                'stderr': {
                    'class': 'logging.StreamHandler',
                    'level': 'WARNING',
                    'formatter': console_formatter,
                    'stream': 'ext://sys.stderr',
                },
                'file': {
                    'class': 'logging.handlers.RotatingFileHandler',
                    'level': 'DEBUG',
                    'formatter': 'detailed',
                    'filename': 'debug.log',
                    'maxBytes': 10485760,
                    'backupCount': 3,
                    'encoding': 'utf8'
                },
                'syslog': {
                    'class': 'logging.handlers.SysLogHandler',
                    'level': 'WARN',
                    'address': '/dev/log',
                    'facility': 'local0',
                    'formatter': 'detailed',
                },
            },
            'root': {
                'level': 'DEBUG',
                'handlers': ['stdout', 'stderr', 'file', 'syslog']
            }
        })

if __name__ == '__main__':
    LogConfig.initialize()
    print('-----')
    logging.debug('test debug')
    logging.info('test info')
    logging.warn('test warn')
    logging.error('test error')
    logging.critical('test critical')

    os.environ['DEBUG'] = 'true'
    print('-----')
    LogConfig.initialize()
    logging.debug('test debug on console')

