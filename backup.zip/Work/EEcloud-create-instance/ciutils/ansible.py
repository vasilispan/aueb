import os
import json

from ciutils.executor import Executor

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))


class AnsibleRunner(object):
    ansible_dir = os.path.join(os.path.dirname(SCRIPT_DIR), 'ansible')

    def __init__(self, ip, identity_file=None, retries=0):
        self.ip = ip
        self.retries = retries
        self.identity_file = identity_file

    def run(self, playbook_file, variables=None):
        config_path = os.path.join(self.ansible_dir, 'ansible.cfg')
        plugins_path = os.path.join(self.ansible_dir, 'plugins')
        book_path = os.path.join(self.ansible_dir, playbook_file)
        opts = []
        if self.identity_file is not None:
            opts.append('--private-key {}'.format(self.identity_file))
        if variables is not None:
            opts.append("-e '{}'".format(json.dumps(variables)))
        ansible_cmd_parts = ['PYTHONUNBUFFERED=1',
                             'ANSIBLE_CONFIG={}'.format(config_path),
                             'ANSIBLE_CALLBACK_PLUGINS={}'.format(plugins_path),
                             'ansible-playbook -i {ip}, {opts} {book}'.format(ip=self.ip,
                                                                              opts=' '.join(opts),
                                                                              book=book_path)]
        cmd = '/bin/sh -c "{}"'.format(' '.join(ansible_cmd_parts).replace('"','\\"'))
        Executor(print_progress=True).run(cmd, retries=self.retries, raise_on_stderr=False)

    def create_ci_service(self, service_name, hostname, admins, smtp_server, remote_backup_target, remote_backup_path):
        vars_ = {'ci_service_name': service_name,
                 'hostname': hostname,
                 'admin_email_addresses': admins,
                 'smtp_server': smtp_server,
                 'remote_backup_target': remote_backup_target,
                 'remote_backup_path': remote_backup_path }
        self.run('ci-service.yaml', vars_)

    def create_devel_env(self, user_id, base_image_only=False):
        vars_ = {'intranet_user_id': user_id}
        if base_image_only:
            self.run('devel-env-base.yaml', vars_)
        else:
            self.run('devel-env.yaml', vars_)

    def test(self):
        self.run('test.yaml')
