import unittest

import mock

from ciutils.ddns import DDNSUpdate
from ciutils.executor import Executor


class DDNSUpdateTest(unittest.TestCase):

    @mock.patch.object(Executor, 'run')
    def test_update(self, mocky):
        _ = DDNSUpdate('1.2.3.4', 'test.name').run()
        mocky.assert_called_once_with(
            'nsupdate -d <<-EOF\n'
            '  update delete test.name.dynamic.nsn-net.net A\n'
            '  update add test.name.dynamic.nsn-net.net 10 A 1.2.3.4\n'
            '  send\n'
            'EOF', raise_on_stderr=False)

if __name__ == '__main__':
    unittest.main()
