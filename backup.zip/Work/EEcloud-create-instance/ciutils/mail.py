from email.mime.text import MIMEText
import logging
import smtplib


class Mailer(object):

    def __init__(self, smtp_address):
        self.smtp_address = smtp_address

    def send_mail(self, from_, to, subject, body, cc=None):
        """
        @cc: input as a list
        """
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = from_
        msg['To'] = ','.join(to)
        if cc is not None:
            msg['Cc'] = ','.join(cc)
        s = smtplib.SMTP(self.smtp_address)
        logging.info('Sending email to {} from {} with subject "{}"'.format(to, from_, subject))
        s.sendmail(from_, [to], msg.as_string())
        s.quit()
