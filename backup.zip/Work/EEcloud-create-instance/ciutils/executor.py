import logging
import os
import shlex
import subprocess

from ciutils.result import Result


class ExecutionError(Exception):
    pass


class Executor(object):
    def __init__(self, print_progress=False, shell=False):
        self.shell = shell
        self.print_progress = print_progress

    def run(self, cmd, raise_on_error=True, raise_on_stderr=True, retries=0):
        r = self._run(cmd, retries)
        if raise_on_error:
            if r.status != 0:
                raise ExecutionError('Command "{}" execution status NOT zero: {}'.format(cmd, str(r)))
        if raise_on_stderr:
            if r.stderr:
                raise ExecutionError('Command "{}" execution stderr not empty: {}'.format(cmd, str(r)))
        return r

    def _run(self, cmd, retries):
        logging.debug('Executing command: "{}"'.format(cmd))
        r = self._execute(cmd)
        while r.status != 0 and retries > 0:
            logging.debug('Retrying, retries left: {}'.format(retries))
            retries -= 1
            r = self._execute(cmd)
            logging.debug('Result: "{}"'.format(str(r)))
            if r.status == 0:
                break
        return r

    def _execute(self, cmd):
        if not self.shell:
            cmd_args = shlex.split(cmd)
        else:
            cmd_args = cmd
        p = subprocess.Popen(cmd_args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=self.shell)
        if self.print_progress:
            stdout, stderr = self._communicate_async(p)
        else:
            stdout, stderr = p.communicate()
        r = Result(p.returncode, stdout, stderr)
        return r

    def _communicate_async(self, popen_obj):
        tmp_stdout = []
        lines_iterator = iter(popen_obj.stdout.readline, b"")
        for line in lines_iterator:
            tmp_stdout.append(line)
            print line,
        _, stderr = popen_obj.communicate()
        stdout = ''.join(tmp_stdout)
        return stdout, stderr

    def ssh(self, target, cmd, identity_file=None, raise_on_error=True, retries=0):
        cmd_parts = ['ssh',
                     '-q',
                     '-o StrictHostKeyChecking=no',
                     '-o UserKnownHostsFile=/dev/null',
                     '-o ConnectTimeout=1',
                     '-o ConnectionAttempts=1']
        if identity_file is not None:
            cmd_parts += ['-o BatchMode=yes',
                          '-o IdentitiesOnly=yes',
                          '-i {}'.format(os.path.expanduser(identity_file))]
        cmd_parts.append('root@{target} "{cmd}"'.format(target=target, cmd=cmd))
        return self.run(' '.join(cmd_parts), raise_on_error, retries)
