

class Result(object):

    def __init__(self, status, stdout, stderr):
        self.status = status
        self.stdout = stdout
        self.stderr = stderr

    @property
    def str_status(self):
        return 'Status:"{}"'.format(self.status)

    @property
    def str_stdout(self):
        return 'Stdout:"{}"'.format(self.stdout)

    @property
    def str_stderr(self):
        return 'Stderr:"{}"'.format(self.stderr)

    def __str__(self):
        return '\n'.join([self.str_status, self.str_stdout, self.str_stderr])

    def omit_stdout(self):
        return '\n'.join([self.str_status, 'Stdout:<omitted>', self.str_stderr])
