
from ciutils.executor import Executor


class DDNSUpdate(object):

    def __init__(self, ip, name, ddns_server='dynamic.nsn-net.net'):
        self.ip = ip
        self.name = name
        self.ddns_server = ddns_server

    @property
    def fqdn(self):
        return '{}.{}'.format(self.name, self.ddns_server)

    def run(self):
        cmd = '''nsupdate -d <<-EOF
  update delete {fqdn} A
  update add {fqdn} 10 A {ip}
  send
EOF'''.format(fqdn=self.fqdn, ip=self.ip)
        Executor(shell=True).run(cmd, raise_on_stderr=False)
