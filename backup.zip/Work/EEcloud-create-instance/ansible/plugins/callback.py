import json
from ansible.plugins.callback import CallbackBase


class CallbackModule(CallbackBase):

    def log(self, result):
        print json.dumps(result, indent=4)

    def runner_on_failed(self, host, res, ignore_errors=False):
        self.log(res)

    def runner_on_ok(self, host, res):
        if res.get('changed'):
            self.log(res)

    def runner_on_skipped(self, host, item=None):
        pass

    def runner_on_unreachable(self, host, res):
        self.log(res)

    def runner_on_async_failed(self, host, res, jid):
        self.log(res)

    def playbook_on_import_for_host(self, host, imported_file):
        self.log( imported_file)

    def playbook_on_not_import_for_host(self, host, missing_file):
        self.log(missing_file)
