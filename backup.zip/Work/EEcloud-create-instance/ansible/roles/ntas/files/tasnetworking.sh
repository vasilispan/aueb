#!/bin/bash

function CreateInterfaces {
    local INTERFACES="el0 el1 el2 el3"

	for int in $INTERFACES; do
	  ip link add $int type dummy
	done

    for int in $INTERFACES; do
	  ip link set dev $int up
	done

	#-- Create veth0 and 1 --
	ip link add veth0 type veth peer name veth1
	ip link set dev veth0 up
	ip link set dev veth1 up

	sleep 0.2

	#-- Create IP for veth1 --
	ip addr add 192.168.1.123/24 dev veth1


	#-- Create veth10 and 11 --
	ip link add veth10 type veth peer name veth11
	ip link set dev veth10 up
	ip link set dev veth11 up

	sleep 0.2

	#-- Create IP for veth11 --
	ip addr add 192.168.2.123/24 dev veth11
	ip addr add 192.168.2.124/24 dev veth11
	ip addr add 192.168.2.125/24 dev veth11

	#-- Set MTU --
	local VETHS="veth0 veth1 veth10 veth11"
	for int in $VETHS; do
	  ip link set dev $int mtu 1448
	done

	ip link add link el3 ctrlext type ipvlan mode l2
	#ip link add ctrlext type dummy
	ip link set dev ctrlext up

	sleep 0.2

	ip addr add 192.168.2.123/24 dev ctrlext
	ip addr add 192.168.2.124/24 dev ctrlext
	ip addr add 192.168.2.125/24 dev ctrlext
	ip addr add 192.168.2.130/24 dev ctrlext
	ip addr add 192.168.2.131/24 dev ctrlext
	ip addr add 192.168.2.132/24 dev ctrlext
	ip addr add 192.168.2.133/24 dev ctrlext

}

function SetBridgeConfig {
#	echo "Configuring br_ interfaces"
	#-- Set generated bridge aging --
#	brctl setageing br_ctrlpub 0
#	brctl setageing br_ctrl 0
#	brctl setageing br_oam 0
#	brctl setageing br_oampub 0

	#-- Add veth0 to bridge --
	brctl addif br_oampub veth0

	#-- Add veth10 to bridge --
	brctl addif br_ctrlpub veth10
}


CreateInterfaces
SetBridgeConfig
