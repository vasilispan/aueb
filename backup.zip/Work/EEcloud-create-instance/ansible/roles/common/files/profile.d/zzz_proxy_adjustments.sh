no_proxy_domains=".nsn-rdnet.net"

if [ -n "$no_proxy" ]; then
  export no_proxy="$no_proxy,$no_proxy_domains"
else
  export no_proxy="$no_proxy_domains"
fi
