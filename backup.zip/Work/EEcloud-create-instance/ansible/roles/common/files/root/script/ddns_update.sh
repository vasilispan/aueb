#!/bin/sh

domain=".dynamic.nsn-net.net"

_help() {
  echo "usage: $0 <ip> <name>"
  echo "DNS name will be: <name>$domain"
}

[ $# -ne 2 ] && _help && exit 1
[ "$1" == "-h" -o "$1" == "--help" ] && _help && exit 0

ip=$1
fqdn="${2}$domain"

nsupdate -d <<-EOF
  update delete ${fqdn} A
  update add ${fqdn} 10 A $ip
  send
EOF
date > /tmp/$(basename $0).timestamp

