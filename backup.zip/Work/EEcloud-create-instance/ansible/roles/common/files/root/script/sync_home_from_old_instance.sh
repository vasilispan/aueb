#!/bin/sh

_usage() {
  echo "Usage: $0 <ip>"
}

_help() {
  _usage
  exit 0
}

_abort() {
  _usage
  echo "ERROR: $1"
  exit 1
}

[ -z "$1" ] && _abort "Please enter source IP as argument"

[ "$1" == '-h' -o "$1" == "--help" ] && _help

set -x
rsync -avP --exclude=lost+found root@$1:/home/ /home/

