# Create and configre EECloud instances

## Requirements

* EE Cloud
    * Access credentials: eucarc file 
    * Preconfigured security group with necessary ports open for services
    * Preconfigured key pair
* Execution environment
    * Packages
        * ansible
        * sshpass
        * euca2ools

## Steps

### 1. Prepare

1. Clone
    * `git clone ssh://git@gitlab.fp.nsn-rdnet.net/common/eecloud-create-instance && cd eecloud-create-instance`
1. Configure
    * `vim site.cfg`

### 2. Create

Common execution pattern: `<variables> PYTHONPATH=. python eucatools/script/<item>/create.py <args>`


#### Generic options

Options and configurations common to all types of instances. Passed through variables:

* DEBUG=true
* SITE_CONFIG_PATH=</some/absolute/path> 

Example: `DEBUG=true SITE_CONFIG_PATH=/root/esclor86-site.cfg  PYTHONPATH=. python eucatools/script/ci_service/create.py <args>`

**NOTE:** `http_proxy=""` might be required in case the running environment has proxy configured by default


#### Item related options

Script specific options are passed through script opts/args. To see these:

`python eucatools/script/<item>/create.py --help` 


### 3. Re-run ansible only

To reconfigure the existing instance: `--ansible-only <ip>`

**NOTE:** Do NOT execute on live environments. This option is mostly for development work.


## CI-Service specific details

### Generic

#### Backups

All created services take backups as necessary via cron jobs. The location is localhost by default.

To configure backups:

1. provide `--remote-backup-*` arguments on the command line
2. add public key `ansible/backup_service.pub` to authorized keys of the backup target


### ReviewBoard

GUI admin:
* username: admin
* password: admin

Other default configuration visible in: `ansible/roles/reviewboard/vars/main.yaml`
