from eucatools.object.instance import Instance
from eucatools.object.volume import Volume
from eucatools.objectfactory import ObjectFactory
from eucatools.testutils.fake_euca_response import \
    describe_instance_running, describe_volume_available, describe_volume_attached, describe_snapshot_completed_tagged


def create_fake_instance(id_='fake-id'):
    return Instance('INSTANCE\t{id}\temi-6d1628cb\t{name}\teuca-10-254-84-234.eucalyptus.internal\trunning\tcloudman\t0\t\tm1.large\t2015-12-15T15:21:18.415Z\tesclor84_1\t\t\t\tmonitoring-disabled\t{ip}\t10.254.84.234\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64'.format(ip='1.2.3.4', name='fake-name', id=id_))


def create_fake_volume():
    return Volume('VOLUME\t{id}\t2\t\tesclor84_2\tavailable\t2015-09-16T07:25:01.279Z\tstandard\t'.format(id='fake-id'))


def get_fake_instance():
    return ObjectFactory(describe_instance_running().stdout).instance


def get_fake_snapshot():
    return ObjectFactory(describe_snapshot_completed_tagged().stdout).snapshot


def get_fake_volume():
    return ObjectFactory(describe_volume_available().stdout).volume


def get_attached_fake_volume():
    return ObjectFactory(describe_volume_attached().stdout).volume
