_default_conf = '''[email]
{smtp}
{admins}

[ee]
eucarc = /home/schydeni/esclor86/eucarc
private-key-file = /home/schydeni/esclor86/cloudman.pem
az = esclor86_2
keypair = cloudman
security-group = default

[ee_images]
fedora24 = i-fake-image
'''


def get_default_config():
    return _get_side_effect(_default_conf.format(smtp='', admins=''))


def get_modified_config():
    return _get_side_effect(
        _default_conf.format(smtp='smtp-server = test-snmp-server',
                             admins='admins = admin1-email'))

def get_2_admins():
    return _get_side_effect(
        _default_conf.format(smtp='',
                             admins='admins = admin1-email,admin2-email'))

def _get_side_effect(conf_file):
    return conf_file.splitlines(1) + ['']
