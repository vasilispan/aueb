from eucatools.testutils.fake_executor_result import _create_success_result, _create_fail_result


### INSTANCE ###
def create_instance_pending():
    return _create_success_result('''RESERVATION\tr-3bb81217\t216572776225\tdefault
INSTANCE\ti-c67d67e7\temi-d7c3110f\teuca-10-39-36-252.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-83-91.eucalyptus.internal\tpending\t\t0\t\tm1.small\t2016-01-11T12:17:32.433Z\tesclor84_1\t\t\t\tmonitoring-disabled\t10.39.36.252\t10.254.83.91\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64
''')


def create_instance_running():
    return _create_success_result('''RESERVATION\tr-fa873f42\t216572776225\tdefault
INSTANCE\ti-3288af51\temi-d96a3efb\teuca-10-39-39-145.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-68-62.eucalyptus.internal\trunning\tcloudman\t0\t\tm3.2xlarge\t2015-10-23T08:41:41.886Z\tesclor84_1\t\t\t\tmonitoring-enabled\t10.39.39.145\t10.254.68.62\t\t\tinstance-store\t\t\t\t\thvm\t\t12303f6b-3f6e-4642-b985-c6c0e133171b\tsg-711173f7\t\t\t\tx86_64
''')


def describe_instance_multiple():
    return _create_success_result('''RESERVATION\tr-14082052\t216572776225\tdefault
INSTANCE\ti-0d670729\temi-d7c3110f\teuca-10-39-38-226.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-81-142.eucalyptus.internal\trunning\tcloudman\t0\t\tm1.large\t2015-11-16T12:13:24.396Z\tesclor84_1\t\t\t\tmonitoring-disabled\t10.39.38.226\t10.254.81.142\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64
BLOCKDEVICE\t/dev/vdc\tvol-970c7e17\t2015-11-16T12:47:26.467Z\tfalse\t\t
TAG\tinstance\ti-0d670729\tName\tmaaniemi
RESERVATION\tr-f127f76c\t216572776225\tdefault
INSTANCE\ti-b12cb8e5\temi-fd4e2bef\teuca-10-39-39-231.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-110-22.eucalyptus.internal\trunning\tmikkoJenkAvain\t0\t\tm1.small\t2016-01-07T09:04:26.342Z\tesclor84_2\t\t\t\tmonitoring-enabled\t10.39.39.231\t10.254.110.22\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64
TAG\tinstance\ti-b12cb8e5\tName\tmikkosmtp
TAG\tinstance\ti-b12cb8e5\ttype\tprivate_server
''')


def describe_instance_multiple_for_same_user():
    return _create_success_result('''RESERVATION\tr-14082052\t216572776225\tdefault
INSTANCE\ti-0d670729\temi-d7c3110f\teuca-10-39-38-226.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-81-142.eucalyptus.internal\trunning\tcloudman\t0\t\tm1.large\t2015-11-16T12:13:24.396Z\tesclor84_1\t\t\t\tmonitoring-disabled\t10.39.38.226\t10.254.81.142\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64
BLOCKDEVICE\t/dev/vdc\tvol-970c7e17\t2015-11-16T12:47:26.467Z\tfalse\t\t
TAG\tinstance\ti-0d670729\tName\tmaaniemi
RESERVATION\tr-f127f76c\t216572776225\tdefault
INSTANCE\ti-b12cb8e5\temi-fd4e2bef\teuca-10-39-39-231.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-110-22.eucalyptus.internal\trunning\tmikkoJenkAvain\t0\t\tm1.small\t2016-01-07T09:04:26.342Z\tesclor84_2\t\t\t\tmonitoring-enabled\t10.39.39.231\t10.254.110.22\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64
TAG\tinstance\ti-b12cb8e5\tName\tmaaniemi
TAG\tinstance\ti-b12cb8e5\ttype\tprivate_server
INSTANCE\ti-6240545b\temi-3f684f3d\teuca-10-39-37-117.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-67-106.eucalyptus.internal\trunning\tcloudman\t0\t\tm1.xlarge\t2015-10-23T07:31:58.451Z\tesclor84_1\t\t\t\tmonitoring-disabled\t10.39.37.117\t10.254.67.106\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64
TAG\tinstance\ti-6240545b\tName\tNFS-server
''')


def describe_instance_shuttingdown():
    return _create_success_result('''RESERVATION\tr-57b5ad2a\t216572776225\tdefault
INSTANCE\ti-c67d67e7\temi-d7c3110f\teuca-10-39-36-252.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-83-91.eucalyptus.internal\tshutting-down\t\t0\t\tm1.small\t2016-01-11T12:17:32.433Z\tesclor84_1\t\t\t\tmonitoring-disabled\t10.39.36.252\t10.254.83.91\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64
''')


def describe_instance_terminated():
    return _create_success_result('''RESERVATION\tr-57b5ad2a\t216572776225\t
INSTANCE\ti-c67d67e7\temi-d7c3110f\t\t\tterminated\t\t0\t\tm1.small\t2016-01-11T12:20:32.555Z\tesclor84_1\t\t\t\tmonitoring-disabled\t\t\t\t\tinstance-store\t\t\t\t\thvm\t\t\t\t\t\t\tx86_64
''')


def describe_instance_pending():
    return _create_success_result('''RESERVATION\tr-57b5ad2a\t216572776225\tdefault
INSTANCE\ti-c67d67e7\temi-d7c3110f\teuca-10-39-38-86.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-71-117.eucalyptus.internal\tpending\t\t0\t\tm1.small\t2016-01-11T12:20:32.555Z\tesclor84_1\t\t\t\tmonitoring-disabled\t10.39.38.86\t10.254.71.117\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64
''')


def describe_instance_running(id_='i-c67d67e7'):
    return _create_success_result('''RESERVATION\tr-fa873f42\t216572776225\tdefault
INSTANCE\t{id}\temi-d96a3efb\teuca-10-39-39-145.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-68-62.eucalyptus.internal\trunning\tcloudman\t0\t\tm3.2xlarge\t2015-10-23T08:41:41.886Z\tesclor84_1\t\t\t\tmonitoring-enabled\t10.39.39.145\t10.254.68.62\t\t\tinstance-store\t\t\t\t\thvm\t\t12303f6b-3f6e-4642-b985-c6c0e133171b\tsg-711173f7\t\t\t\tx86_64
TAG\tinstance\ti-3288af51\tName\tschydeni
'''.format(id=id_))


def describe_instance_running_tagged():
    return _create_success_result('''RESERVATION\tr-fa873f42\t216572776225\tdefault
INSTANCE\ti-3288af51\temi-d96a3efb\teuca-10-39-39-145.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-68-62.eucalyptus.internal\trunning\tcloudman\t0\t\tm3.2xlarge\t2015-10-23T08:41:41.886Z\tesclor84_1\t\t\t\tmonitoring-enabled\t10.39.39.145\t10.254.68.62\t\t\tinstance-store\t\t\t\t\thvm\t\t12303f6b-3f6e-4642-b985-c6c0e133171b\tsg-711173f7\t\t\t\tx86_64
TAG\tinstance\ti-3288af51\tName\tvgp-slave5-build
TAG\tinstance\ti-3288af51\tjenkins_slave_type\tdemand
TAG\tinstance\ti-3288af51\ttype\tvgp
''')


def terminate_instance():
    return _create_success_result('INSTANCE\ti-c67d67e7\trunning\tshutting-down')

### TAG ###


def create_tag(key='ci-service', value='test-server'):
    return _create_success_result('TAG\tinstance\ti-e737b2fb\t{}\t{}'.format(key, value))


def create_tags():
    return _create_success_result('''TAG\tinstance\ti-fe688a76\tci-service\t
TAG\tinstance\ti-fe688a76\trepository\tosr/autocom
''')


def describe_tags():
    return _create_success_result('''TAG\tinstance\ti-fe688a76\tci-service\t
TAG\tinstance\ti-fe688a76\trepository\tosr/autocom
TAG\tsnapshot\tsnap-f75afe0c\tName\tSnap1
TAG\tvolume\tvol-ed4ef53a\tName\tantti volume
''')

### VOLUME ###


def create_volume():
    return _create_success_result('VOLUME\tvol-4f3d5231\t50\t\tesclor84_1\tcreating\t2016-01-08T13:20:51.292Z')


def describe_volume_creating(tagstr=''):
    return _create_success_result('''VOLUME\tvol-4f3d5231\t50\t\tesclor84_1\tcreating\t2015-09-16T07:25:01.279Z\tstandard\t
{}'''.format(tagstr))


def describe_volume_creating_tagged():
    return describe_volume_creating('''TAG\tvolume\tvol-4f3d5231\tName\tsakutest
''')


def describe_volume_available(tagstr=''):
    return _create_success_result('''VOLUME\tvol-4f3d5231\t50\t\tesclor84_1\tavailable\t2015-09-16T07:25:01.279Z\tstandard\t
{}'''.format(tagstr))


def describe_volume_available_tagged():
    return describe_volume_available('''TAG\tvolume\tvol-4f3d5231\tName\tsakutest
''')


def describe_volume_attaching():
    return _create_success_result('''VOLUME\tvol-4f3d5231\t1\t\tesclor84_2\tsome-not-ready-yet-state\t2016-01-11T13:31:55.606Z\tstandard\t
ATTACHMENT\tvol-4f3d5231\ti-c67d67e7\t/dev/vdc\tattaching\t2016-01-12T06:47:00.543Z
TAG\tvolume\tvol-4f3d5231\tName\tsakutest
''')


def describe_volume_detaching():
    return _create_success_result('''VOLUME\tvol-4f3d5231\t1\t\tesclor84_2\tin-use\t2016-01-11T13:31:55.606Z\tstandard\t
ATTACHMENT\tvol-4f3d5231\ti-c67d67e7\t/dev/vdc\tdetaching\t2016-01-12T06:47:00.543Z
TAG\tvolume\tvol-4f3d5231\tName\tsakutest
''')


def describe_volume_attached(instance_id=''):
    return _create_success_result('''VOLUME\tvol-4f3d5231\t1\t\tesclor84_2\tin-use\t2016-01-11T13:31:55.606Z\tstandard\t
ATTACHMENT\tvol-4f3d5231\ti-c67d67e7\t/dev/vdc\tattached\t2016-01-12T06:47:00.543Z
TAG\tvolume\tvol-4f3d5231\tName\tsakutest
''')


def describe_volumes():
    return _create_success_result('''VOLUME\tvol-ed4ef53a\t10\t\tesclor84_1\tavailable\t2015-09-07T06:17:55.602Z\tstandard\t
TAG\tvolume\tvol-ed4ef53a\tName\tantti volume
VOLUME\tvol-d7471216\t50\t\tesclor84_1\tcreating\t2016-01-08T14:20:59.776Z\tstandard\t
VOLUME\tvol-b594a024\t15\t\tesclor84_1\tin-use\t2016-01-06T03:04:53.620Z\tstandard\t
ATTACHMENT\tvol-b594a024\ti-3647d4f0\t/dev/vdc\tattached\t2016-01-06T03:04:54.375Z
TAG\tvolume\tvol-b594a024\tName\tf1cheng
''')


### SNAPSHOT ###
def create_snapshot():
    return _create_success_result('SNAPSHOT\tsnap-1b1ce45e\tvol-37f95d99\tpending\t2016-01-20T08:18:35.842Z\t216572776225\t15\tdev-temporary')


def delete_snapshot():
    return _create_success_result('')


def describe_snapshot_pending():
    return _create_success_result('SNAPSHOT\tsnap-1b1ce45e\tvol-37f95d99\tpending\t2016-01-20T08:18:35.842Z\t25%\t216572776225\t15\tdev-temporary')


def describe_snapshot_pending_tagged():
    return _create_success_result('''SNAPSHOT\tsnap-1b1ce45e\tvol-37f95d99\tpending\t2016-01-20T08:18:35.842Z\t34%\t216572776225\t15\tdev-temporary
TAG\tsnapshot\tsnap-1b1ce45e\tName\tdev-schydeni
TAG\tsnapshot\tsnap-1b1ce45e\tdev-temporary\t
''')


def describe_snapshot_completed_tagged():
    return _create_success_result('''SNAPSHOT\tsnap-1b1ce45e\tvol-37f95d99\tcompleted\t2016-01-20T08:18:35.842Z\t100%\t216572776225\t15\tdev-temporary
TAG\tsnapshot\tsnap-1b1ce45e\tName\tdev-schydeni
TAG\tsnapshot\tsnap-1b1ce45e\tdev-temporary\t
''')


def describe_snapshots():
    return _create_success_result('''SNAPSHOT\tsnap-1b1ce45e\tvol-37f95d99\tcompleted\t2016-01-20T08:18:35.842Z\t100%\t216572776225\t15\tdev-temporary
TAG\tsnapshot\tsnap-1b1ce45e\tName\tdev-schydeni
TAG\tsnapshot\tsnap-1b1ce45e\tdev-temporary\t
SNAPSHOT\tsnap-f75afe0c\tvol-ca101461\tcompleted\t2015-09-15T11:56:39.951Z\t100%\t216572776225\t50\t
TAG\tsnapshot\tsnap-f75afe0c\tName\tSnap1
''')


def empty_response():
    return _create_success_result('')

### ATTACH ###


def attach_volume():
    return _create_success_result('ATTACHMENT\tvol-7b1f5449\ti-e240a214\t/dev/vdc\tattaching\t2016-01-12T06:47:00.550Z')


def attach_volume_fail_inuse():
    return _create_fail_result('euca-attach-volume: error (VolumeInUse): Volume already attached: vol-7b1f5449')


def detach_volume():
    return _create_success_result('ATTACHMENT\tvol-7b1f5449\ti-e240a214\t/dev/vdc\tdetaching\t2016-01-12T06:47:00.543Z')
