
from ciutils.result import Result


def _create_success_result(stdout):
    return Result(0, stdout, '')


def _create_fail_result(stdout):
    return Result(1, stdout, '')
