
from ciutils.result import Result

res_success = Result(0, 'uptime', '')
res_fail = Result(255, '', '')
