import unittest

from eucatools.object.base import ParseError


ut = unittest.TestCase('__init__')


def assert_attrs(object_, **expected_pairs):
    for attr, value in expected_pairs.items():
        _assert_attr(object_, attr, value)


def _assert_attr(object_, attr, expected_value):
    ut.assertEqual(getattr(object_, attr), expected_value)


def assert_tags(object_, expected_tags):
    #ut.assertEqual(len(object_.tags), len(expected_tags))
    tags = [(t.key, t.value) for t in object_.tags]
    ut.assertEqual(tags, expected_tags)


def assert_attachment(volume, expected_attachment):
    if expected_attachment is None:
        ut.assertEqual(volume.attachment, None)
    else:
        assert_attrs(volume.attachment, **expected_attachment)


def assert_calls(calls, expected_calls):
    ut.assertEqual(len(calls), len(expected_calls))
    for i, expected_call in enumerate(expected_calls):
        ut.assertEqual(expected_call, calls[i])
