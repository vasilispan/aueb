class EECloudException(Exception):
    pass


class ValidationError(EECloudException):
    pass
