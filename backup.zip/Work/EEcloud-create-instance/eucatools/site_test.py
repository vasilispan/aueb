import unittest
import os
import mock

from eucatools.site import SiteConfig

from eucatools.testutils.fake_site import get_default_config, get_modified_config, get_2_admins


@mock.patch('__builtin__.open', create=True)
class SiteConfigTest(unittest.TestCase):
    def setUp(self):
        pass

    def test_default_config(self, mock_open):
        mock_open.return_value.readline.side_effect = get_default_config()
        config = SiteConfig()
        self.assertEqual(config.email, {})
        self.assertEqual(config.ee, {'security-group': 'default', 'keypair': 'cloudman', 'az': 'esclor86_2',
                                     'eucarc': '/home/schydeni/esclor86/eucarc',
                                     'private-key-file': '/home/schydeni/esclor86/cloudman.pem'})
        self.assertEqual(config.ee_images, {'fedora24': 'i-fake-image'})

    def test_modified_config(self, mock_open):
        mock_open.return_value.readline.side_effect = get_modified_config()
        config = SiteConfig()
        self.assertEqual(config.email, {'admins': 'admin1-email',  'smtp-server': 'test-snmp-server'})

    def test_multiple_admins(self, mock_open):
        mock_open.return_value.readline.side_effect = get_2_admins()
        config = SiteConfig()
        self.assertEqual(config.email, {'admins': 'admin1-email,admin2-email'})

    @mock.patch.dict(os.environ, {'SITE_CONFIG_PATH': '/my/test/site.cfg'})
    @mock.patch('os.path.isfile', return_value=True)
    def test_site_config_path_set(self, mock_isfile, mock_open):
        mock_open.return_value.readline.side_effect = get_default_config()
        SiteConfig()
        mock_open.assert_called_once_with('/my/test/site.cfg')


if __name__ == "__main__":
    unittest.main()
