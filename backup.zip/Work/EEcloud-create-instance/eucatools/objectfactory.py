
import logging

from eucatools.object.attachment import Attachment
from eucatools.object.base import ParseError
from eucatools.object.blockdevice import Blockdevice
from eucatools.object.instance import Instance
from eucatools.object.tag import Tag
from eucatools.object.snapshot import Snapshot
from eucatools.object.volume import Volume


class ObjectFactory(object):

    def __init__(self, data=None):
        self.data = data
        self.objects = self._create(data)

    def _create(self, data):
        objects = []
        for line in data.splitlines():
            for parser in [Snapshot, Instance, Tag, Volume, Attachment, Blockdevice]:
                try:
                    o = parser(line)
                    objects.append(o)
                    break
                except ParseError:
                    pass
        # if not objects:
        #    raise ParseError('Could not parse any objects from: "{}"'.format(data))
        logging.debug('Parsed objects: {}'.format(objects))
        return objects

    @property
    def instances(self):
        return self._get_objects(Instance, self._instance_filler)

    @property
    def instance(self):
        return self._get_exactly_one_item(self.instances)

    @property
    def volumes(self):
        return self._get_objects(Volume, self._volume_filler)

    @property
    def volume(self):
        return self._get_exactly_one_item(self.volumes)

    @property
    def snapshots(self):
        return self._get_objects(Snapshot, self._snapshot_filler)

    @property
    def snapshot(self):
        return self._get_exactly_one_item(self.snapshots)

    @property
    def tags(self):
        return self._filter_objects(self.objects, Tag)

    @property
    def tag(self):
        return self._get_exactly_one_item(self.tags)

    @property
    def attachments(self):
        return self._filter_objects(self.objects, Attachment)

    @property
    def attachment(self):
        return self._get_exactly_one_item(self.attachments)

    def _get_objects(self, object_type, object_filler):
        if not self.objects:
            return []
        unpopulated_object_map = []
        requested_objects = [o for o in self.objects if isinstance(o, object_type)]

        for o in requested_objects:
            index = self.objects.index(o)
            if o == requested_objects[-1]:  # last
                related_objects = self.objects[index + 1:]
            else:
                next_object_index = self.objects.index(requested_objects[requested_objects.index(o) + 1])
                related_objects = self.objects[index + 1:next_object_index]
            unpopulated_object_map.append((o, related_objects))

        return self._populate_objects(unpopulated_object_map, object_filler)

    def _populate_objects(self, unpopulated_object_map, object_filler):
        populated = []
        for o, related_objects in unpopulated_object_map:
            object_filler(o, related_objects)
            populated.append(o)
        return populated

    def _get_exactly_one_item(self, list_):
        if len(list_) != 1:
            raise ParseError('Failed to validate only 1 exists, found {} in: {}'.format(len(list_), list_))
        return list_[0]

    def _filter_objects(self, objects, object_type):
        return [o for o in objects if isinstance(o, object_type)]

#     def _filter_object(self, objects, object_type):
#         objects = self._filter_objects(objects, object_type)
#         return self._get_exactly_one_item(objects)

    def _snapshot_filler(self, object_, related_objects):
        self._assign_tags(object_, related_objects)

    def _instance_filler(self, object_, related_objects):
        self._assign_tags(object_, related_objects)
        self._assign_blockdevices(object_, related_objects)

    def _volume_filler(self, object_, related_objects):
        self._assign_tags(object_, related_objects)
        self._assign_attachment(object_, related_objects)

    def _assign_tags(self, object_, related_objects):
        for o in self._filter_objects(related_objects, Tag):
            object_.tags.append(o)

    def _assign_blockdevices(self, object_, related_objects):
        for o in self._filter_objects(related_objects, Blockdevice):
            object_.blockdevices.append(o)

    def _assign_attachment(self, object_, related_objects):
        attachments = self._filter_objects(related_objects, Attachment)
        if len(attachments) == 1:
            object_.attachment = attachments[0]
