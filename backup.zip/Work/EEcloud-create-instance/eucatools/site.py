import os
import ConfigParser


class SiteConfig(object):

    def __init__(self):
        site_config_path = os.environ.get('SITE_CONFIG_PATH')
        if not site_config_path:
            site_config_path = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))), 'site.cfg')
        if not os.path.isfile(site_config_path):
            raise Exception('Could not find site config file: {}'.format(site_config_path))
        self.config = ConfigParser.ConfigParser()
        self.config.readfp(open(site_config_path))

    def __getattr__(self, item):
        return dict(self.config.items(item))
