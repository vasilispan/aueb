
import re

from eucatools.object.base import TaggedObject


class Snapshot(TaggedObject):

    type_id = 'SNAPSHOT'
    fields = {'id': 1,
              'volume_id': 2,
              'state': 3,
              'percent': 5}

    def format_percent(self, value):
        match = re.match(r'^(\d+)%$', value)
        if match:
            return int(match.group(1))
        return 0
