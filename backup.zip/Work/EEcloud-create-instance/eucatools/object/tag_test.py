import unittest

from eucatools.object.tag import Tag
from eucatools.testutils.validate import assert_attrs


class TagTest(unittest.TestCase):

    def test_empty_value(self):
        assert_attrs(Tag('TAG\tinstance\ti-7c4fdbc9\tci-service\t'),
                     id='i-7c4fdbc9', key='ci-service', value=None)

    def test_slash(self):
        assert_attrs(Tag('TAG\tinstance\ti-fe688a76\trepository\tosr/autocom'),
                     id='i-fe688a76', key='repository', value='osr/autocom')

    def test_space(self):
        assert_attrs(Tag('TAG\tvolume\tvol-ed4ef53a\tName\tantti volume'),
                     id='vol-ed4ef53a', key='Name', value='antti volume')

    def test_str(self):
        self.assertEqual(str(Tag('TAG\tvolume\tvol-ed4ef53a\tName\tantti volume')),
                         '<TAG: value=antti volume, id=vol-ed4ef53a, key=Name>')

    def test_str_simple(self):
        self.assertEqual(Tag('TAG\tvolume\tvol-ed4ef53a\tName\tantti volume').simple,
                         '<Name=antti volume>')

if __name__ == "__main__":
    unittest.main()
