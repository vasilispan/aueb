import unittest

from eucatools.object.instance import Instance
from eucatools.testutils.validate import assert_attrs


terminated = 'INSTANCE\ti-f072403e\temi-fd4e2bef\t\t\tterminated\tmikkoJenkAvain\t0\t\tm3.2xlarge\t2016-01-04T05:13:07.554Z\tesclor84_2\t\t\t\tmonitoring-enabled\t\t\t\t\tinstance-store\t\t\t\t\thvm\t\t\t\t\t\t\tx86_64'
running = 'INSTANCE\ti-280ec995\temi-6d1628cb\teuca-10-39-39-69.eucalyptus.esclor84.eecloud.nsn-rdnet.net\teuca-10-254-84-234.eucalyptus.internal\trunning\tcloudman\t0\t\tm1.large\t2015-12-15T15:21:18.415Z\tesclor84_1\t\t\t\tmonitoring-disabled\t10.39.39.69\t10.254.84.234\t\t\tinstance-store\t\t\t\t\thvm\t\t\tsg-711173f7\t\t\t\tx86_64'


class InstanceTest(unittest.TestCase):

    def test_running(self):
        i = Instance(running)
        assert_attrs(
            i, id='i-280ec995', image_id='emi-6d1628cb', name='euca-10-39-39-69.eucalyptus.esclor84.eecloud.nsn-rdnet.net', state='running', ip='10.39.39.69')
        self.assertTrue(i.is_running)

    def test_terminated(self):
        i = Instance(terminated)
        assert_attrs(i, id='i-f072403e', name=None, state='terminated', ip=None)
        self.assertFalse(i.is_running)

    def test_str(self):
        self.assertEqual(str(Instance(terminated)),
                         '<INSTANCE: ip=None, image_id=emi-fd4e2bef, state=terminated, id=i-f072403e, name=None, tags=[], blockdevices=[]>')

if __name__ == "__main__":
    unittest.main()
