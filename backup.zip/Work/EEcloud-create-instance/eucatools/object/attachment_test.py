import unittest

from eucatools.object.base import ParseError
from eucatools.object.attachment import Attachment
from eucatools.testutils.validate import assert_attrs


class TagTest(unittest.TestCase):

    def test_volume(self):
        assert_attrs(Attachment('ATTACHMENT\tvol-b594a024\ti-3647d4f0\t/dev/vdc\tattached\t2016-01-06T03:04:54.375Z'),
                     volume_id='vol-b594a024', instance_id='i-3647d4f0', device='/dev/vdc', state='attached')


if __name__ == "__main__":
    unittest.main()
