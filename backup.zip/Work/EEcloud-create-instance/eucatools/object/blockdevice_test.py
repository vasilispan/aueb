import unittest

from eucatools.object.blockdevice import Blockdevice
from eucatools.testutils.validate import assert_attrs


class BlockdeviceTest(unittest.TestCase):

    def test_empty_value(self):
        assert_attrs(Blockdevice('BLOCKDEVICE\t/dev/vdc\tvol-970c7e17\t2015-11-16T12:47:26.467Z\tfalse\t\t'),
                     volume_id='vol-970c7e17', device='/dev/vdc')


if __name__ == "__main__":
    unittest.main()
