
from eucatools.object.base import BaseObject


class Blockdevice(BaseObject):

    type_id = 'BLOCKDEVICE'
    fields = {'device': 1,
              'volume_id': 2}
