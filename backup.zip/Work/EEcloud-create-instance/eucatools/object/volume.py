
from eucatools.object.base import TaggedObject


class Volume(TaggedObject):

    type_id = 'VOLUME'
    fields = {'id': 1,
              'size': 2,
              'az': 4,
              'state': 5}

    def __init__(self, line):
        super(Volume, self).__init__(line)
        self.attachment = None
        self._related_objects.append('attachment')

    def format_size(self, size):
        return int(size)

    @property
    def is_attached(self):
        return True if self.attachment is not None else False
