import unittest

from eucatools.object.snapshot import Snapshot
from eucatools.testutils.validate import assert_attrs


create_response = 'SNAPSHOT\tsnap-1b1ce45e\tvol-37f95d99\tpending\t2016-01-20T08:18:35.842Z\t216572776225\t15\tdev-temporary'
describe_pending_response = 'SNAPSHOT\tsnap-1b1ce45e\tvol-37f95d99\tpending\t2016-01-20T08:18:35.842Z\t34%\t216572776225\t15\tdev-temporary'
describe_completed_response = 'SNAPSHOT\tsnap-1b1ce45e\tvol-37f95d99\tcompleted\t2016-01-20T08:18:35.842Z\t100%\t216572776225\t15\tdev-temporary'


class SnapshotTest(unittest.TestCase):

    def test_create(self):
        assert_attrs(Snapshot(create_response),
                     id='snap-1b1ce45e',
                     volume_id='vol-37f95d99',
                     state='pending',
                     percent=0)

    def test_create_ongoing(self):
        assert_attrs(Snapshot(describe_pending_response),
                     id='snap-1b1ce45e',
                     volume_id='vol-37f95d99',
                     state='pending',
                     percent=34)

    def test_create_complete(self):
        assert_attrs(Snapshot(describe_completed_response),
                     id='snap-1b1ce45e',
                     volume_id='vol-37f95d99',
                     state='completed',
                     percent=100)


if __name__ == "__main__":
    unittest.main()
