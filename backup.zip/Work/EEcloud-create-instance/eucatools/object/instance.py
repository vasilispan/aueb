
from eucatools.object.base import TaggedObject


class Instance(TaggedObject):

    type_id = 'INSTANCE'
    fields = {'id': 1,
              'image_id': 2,
              'name': 3,
              'state': 5,
              'ip': 16}

    def __init__(self, line):
        super(Instance, self).__init__(line)
        self.blockdevices = []
        self._related_objects.append('blockdevices')

#     @property
#     def blockdevice(self):
#         count = len(self.blockdevices)
#         if count == 0:
#             return None
#         if count == 1:
#             return self.blockdevices[0]
#         raise Exception('More than one blockdevice found: {}'.format(self.blockdevices))

    @property
    def is_running(self):
        return self.state == 'running'
