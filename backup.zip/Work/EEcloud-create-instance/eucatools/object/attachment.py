
from eucatools.object.base import BaseObject


class Attachment(BaseObject):

    type_id = 'ATTACHMENT'
    fields = {'volume_id': 1,
              'instance_id': 2,
              'device': 3,
              'state': 4}
