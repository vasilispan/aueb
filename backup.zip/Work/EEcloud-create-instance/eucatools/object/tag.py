from eucatools.object.base import BaseObject


class Tag(BaseObject):

    type_id = 'TAG'
    fields = {'id': 2,
              'key': 3,
              'value': 4}
    #optional_fields = [4]

    def _get_str_simple_content(self):
        return [(self.key, self.value)]
