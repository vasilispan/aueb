import unittest

from eucatools.object.base import ParseError
from eucatools.object.tag import Tag


class BaseTest(unittest.TestCase):

    def test_empty_lise(self):
        self.assertRaisesRegexp(ParseError, 'Empty line, cannot parse', Tag, '')

    def test_no_proper_separator(self):
        self.assertRaisesRegexp(ParseError, 'too few fields 1', Tag, 'TAG  instance  i-7c4fdbc9  ci-service  foobar')

    def test_type_missing_from_line(self):
        self.assertRaisesRegexp(ParseError, 'Type ID "TAG" not found', Tag, 'foo\t\t\t\t')

    def test_missing_field(self):
        t = Tag('TAG\ta\tb\tc\td')
        self.assertRaisesRegexp(Exception, 'Invalid field requested', getattr, t, 'nonexisting')


if __name__ == "__main__":
    unittest.main()
