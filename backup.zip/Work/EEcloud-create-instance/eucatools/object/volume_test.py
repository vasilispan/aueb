import unittest

from eucatools.object.volume import Volume
from eucatools.testutils.validate import assert_attrs


class VolumeTest(unittest.TestCase):

    def test_create(self):
        assert_attrs(Volume('VOLUME\tvol-4f3d5231\t50\t\tesclor84_1\tcreating\t2016-01-08T13:20:51.292Z'),
                     id='vol-4f3d5231', size=50, az='esclor84_1', state='creating')

    def test_available(self):
        assert_attrs(Volume('VOLUME\tvol-9c9890f8\t2\t\tesclor84_2\tavailable\t2015-09-16T07:25:01.279Z\tstandard\t'),
                     id='vol-9c9890f8', size=2, az='esclor84_2', state='available')

    def test_inuse(self):
        assert_attrs(Volume('VOLUME\tvol-a2d41e2d\t15\t\tesclor84_1\tin-use\t2015-11-16T11:09:02.961Z\tstandard\t'),
                     id='vol-a2d41e2d', size=15, az='esclor84_1', state='in-use')

    def test_delete(self):
        assert_attrs(Volume('VOLUME\tvol-4f3d5231'),
                     id='vol-4f3d5231')

#
#     def test_fields(self):
#         validate_empty_fields(Volume, 'VOLUME', 7, raises=[1, 2, 4, 5], raises_not=[])

if __name__ == "__main__":
    unittest.main()
