import re

from eucatools.string import format_object_string


class ParseError(Exception):
    pass


class BaseObject(object):

    type_id = None
    fields = {}
    optional_fields = []

    def __init__(self, line):
        if not line:
            raise ParseError('Empty line, cannot parse')
        self.line = line
        self.items = self._parse_items(line)
        self._related_objects = []
        self._validate()

    def _parse_items(self, line):
        items = re.split(r'\t', line)
        min_count = 2
        field_count = len(items)
        if field_count < min_count:
            raise ParseError(
                'Failed to parse - too few fields {} vs expected {}: "{}"'.format(field_count, min_count, items))
        return items

    def _validate(self):
        self.type
        for f in self.fields:
            getattr(self, f)

    @property
    def type(self):
        type_ = self.items[0]
        if type_ != self.type_id:
            raise ParseError('Type ID "{}" not found'.format(self.type_id))
        return type_

    def __getattr__(self, attr):
        if attr.startswith('__'):
            raise AttributeError
        if attr in self._related_objects:
            return getattr(self, attr)
        elif attr not in self.fields:
            all_fields = self.fields.keys() + self._related_objects
            raise Exception('Invalid field requested: {} ({} fields={})'.format(attr,
                                                                                self.type,
                                                                                all_fields))
        index = self.fields[attr]
        if index < len(self.items):
            item = self.items[index]
            if not item:
                item = None
            if hasattr(self, 'format_' + attr):
                item = getattr(self, 'format_' + attr)(item)
        else:
            item = None
        return item

    def __str__(self):
        return format_object_string(self._get_str_content(), title=self.type, title_separator=': ')

    def _get_str_content(self):
        data_pairs = [(a, getattr(self, a)) for a in self.fields.keys()]
        for attr in self._related_objects:
            related = getattr(self, attr)
            if isinstance(related, list):
                data_pairs += [(attr, [o.simple for o in related])]
            elif related is None:
                data_pairs += [(attr, related)]
            else:
                data_pairs += [(attr, related.simple)]
        return data_pairs

    def _get_str_simple_content(self):
        return self._get_str_content()

    @property
    def simple(self):
        return format_object_string(self._get_str_simple_content())

    @property
    def pretty(self):
        return format_object_string(self._get_str_content(), title=self.type, prefix='=== ', title_separator=' ===\n',
                                    suffix='\n', value_separator=': ', field_separator='\n')


class TaggedObject(BaseObject):

    def __init__(self, line):
        super(TaggedObject, self).__init__(line)
        self._related_objects.append('tags')
        self.tags = []

    @property
    def user_name(self):
        for t in self.tags:
            if t.key == 'Name':
                return t.value
        return None
