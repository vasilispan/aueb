from copy import deepcopy
import logging
import os
import time

from eucatools.eucaapi import EucaApi
from eucatools.exception import EECloudException
from eucatools.objectfactory import ObjectFactory


class StateWaitError(EECloudException):
    pass


empty_userdata = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'config')


class EucaUtils(object):
    def create_instance(self, image='emi-12345678', name=None, instance_type='m1.small', pre_configured_key='cloudman',
                        security_group='default', az='esclor84_1', user_data=None, tags=None, max_wait=300):

        result = EucaApi().create_instance(image, instance_type, pre_configured_key, security_group, az, user_data)
        instance = ObjectFactory(result.stdout).instance
        logging.info('Instance create started: {}'.format(instance))
        self._handle_tag_args(instance.id, name, tags, {'OS': image})
        instance = self._wait_success(
            self._describe_instance_by_object, instance, 'state', 'running', ['terminated', 'shutting-down'],
            iter_wait=3, max_wait=max_wait)
        logging.info('Instance created: {}'.format(instance))
        return instance

    def _handle_tag_args(self, object_id, name, *tag_dicts):
        all_tags = {}
        if name is not None:
            all_tags.update({'Name': name})
        for t in tag_dicts:
            if t is not None:
                all_tags.update(t)
        if all_tags:
            self.create_tags(object_id, all_tags)

    def create_volume(self, az, size=None, snapshot_id=None, name=None, tags=None, max_wait=30):
        result = EucaApi().create_volume(az, size=size, snapshot_id=snapshot_id)
        volume = ObjectFactory(result.stdout).volume
        logging.info('Volume create started: {}'.format(volume))
        self._handle_tag_args(volume.id, name, tags)
        volume = self._wait_success(
            self._describe_volume_by_object, volume, 'state', 'available', iter_wait=1, max_wait=max_wait)
        logging.info('Volume created: {}'.format(volume))
        return volume

    def create_snapshot(self, volume_id, description=None, name=None, tags=None, max_wait=900):
        result = EucaApi().create_snapshot(volume_id, description)
        snapshot = ObjectFactory(result.stdout).snapshot
        logging.info('Snapshot create started: {}'.format(snapshot))
        self._handle_tag_args(snapshot.id, name, tags)
        snapshot = self._wait_success(
            self._describe_snapshot_by_object, snapshot, 'state', 'completed', iter_wait=5, max_wait=max_wait)
        logging.info('Snapshot created: {}'.format(snapshot))
        return snapshot

    def delete_snapshot(self, snapshot_id):
        EucaApi().delete_snapshot(snapshot_id)
        for s in self.describe_snapshots():
            if s.id == snapshot_id:
                raise EECloudException('Snapshot "{}" delete failed, still exists: {}'.format(s.id, s))
        logging.info("Snapshot deleted: {}".format(snapshot_id))

    def create_tags(self, object_id, tags):
        result = self._create_tags(object_id, tags)
        tags = ObjectFactory(result.stdout).tags
        logging.info("Tags created: {}".format([str(t) for t in tags]))
        return tags

    def _create_tags(self, object_id, tags):
        result = EucaApi().create_tags(object_id, tags)
        return result

    def create_tag(self, object_id, tag_key, tag_value):
        result = self._create_tags(object_id, {tag_key: tag_value})
        tag = ObjectFactory(result.stdout).tag
        logging.info("Tag created: {}".format(tag))
        return tag

    def attach_volume(self, instance_id, device, volume_id, max_wait=60):
        EucaApi().attach_volume(instance_id, device, volume_id)
        volume = self.describe_volume(volume_id)
        logging.info("Volume attach started: {}".format(volume))
        self._wait_success(
            self._describe_attachment_by_object, volume.attachment, 'state', 'attached', iter_wait=1, max_wait=max_wait)
        volume = self._wait_success(
            self._describe_volume_by_object, volume, 'state', 'in-use', negative_states=['available'], iter_wait=1,
            max_wait=max_wait)
        logging.info("Volume attached: {}".format(volume))
        return volume

    def detach_volume(self, instance_id, volume_id, max_wait=30):
        volume = self.describe_volume(volume_id)
        result = EucaApi().detach_volume(instance_id, volume_id)
        logging.info("Volume detach started: {}".format(volume))
        volume = self._wait_success(
            self._describe_volume_by_object, volume, 'attachment', None, iter_wait=1, max_wait=max_wait)
        volume = self._wait_success(
            self._describe_volume_by_object, volume, 'state', 'available', iter_wait=1, max_wait=max_wait)
        logging.info("Volume detached: {}".format(volume))
        return volume

    def describe_instances(self, instance_ids=None):
        return self._describe_objects(EucaApi().describe_instances, 'instances', instance_ids)

    def describe_volumes(self, volume_ids=None):
        return self._describe_objects(EucaApi().describe_volumes, 'volumes', volume_ids)

    def describe_snapshots(self, snapshot_ids=None):
        return self._describe_objects(EucaApi().describe_snapshots, 'snapshots', snapshot_ids)

    def describe_instance(self, instance_id):
        return self._describe_single_by_id(instance_id, self.describe_instances)

    def describe_volume(self, volume_id):
        return self._describe_single_by_id(volume_id, self.describe_volumes)

    def describe_snapshot(self, snapshot_id):
        return self._describe_single_by_id(snapshot_id, self.describe_snapshots)

    def describe_user_active_instances(self, user_id):
        instances = self._filter_by_name(user_id, self.describe_instances())
        return [i for i in instances if i.is_running]

    def describe_instance_by_ip(self, ip):
        matching_instances = [i for i in self.describe_instances() if i.ip == ip]
        return self._get_exactly_one(matching_instances)

    def describe_user_volumes(self, user_id):
        volumes = self._filter_by_name(user_id, self.describe_volumes())
        return [v for v in volumes if v.state != 'deleted']

    def describe_user_volumes_az(self,user_id):
        volumes = self._filter_by_name(user_id, self.describe_volumes())
        if volumes:
            return [v.az for v in volumes if v.state != 'deleted']

    def _describe_instance_by_object(self, object_):
        updated = self.describe_instance(object_.id)
        self._log_object_update(object_, updated)
        return updated

    def _describe_volume_by_object(self, object_):
        updated = self.describe_volume(object_.id)
        self._log_object_update(object_, updated)
        return updated

    def _describe_snapshot_by_object(self, object_):
        updated = self.describe_snapshot(object_.id)
        self._log_object_update(object_, updated)
        return updated

    def _log_object_update(self, old, new):
        logging.debug("{} updated:\nold={}\nnew={}".format(old.type_id, old, new))

    def _describe_attachment_by_object(self, object_):
        updated = self.describe_volume(object_.volume_id).attachment
        self._log_object_update(object_, updated)
        return updated

    def _describe_single_by_id(self, object_id, describe_method):
        objects = describe_method([object_id])
        return self._get_exactly_one(objects)

    def _get_exactly_one(self, list_):
        if len(list_) < 1:
            raise EECloudException('Did not receive any objects')
        if len(list_) > 1:
            raise EECloudException('Did receive too many objects: {}'.format(list_))
        return list_[0]

    def _describe_objects(self, describe_method, factory_attribute, object_ids=None):
        if object_ids is not None:
            result = describe_method(object_ids)
        else:
            result = describe_method()
        objects = getattr(ObjectFactory(result.stdout), factory_attribute)
        return objects

    def _filter_by_name(self, name, objects):
        return [i for i in objects if i.user_name == name]

    def _wait_success(self, poll_method, object_, attribute, expected_state, negative_states=None, iter_wait=3,
                      max_wait=300):
        tot_wait = 0
        object_org = deepcopy(object_)
        current_state = getattr(object_, attribute)
        logging.debug('Waiting for "{}" to change "{}" in: {}'.format(attribute, expected_state, object_))
        while current_state != expected_state:
            if negative_states is not None:
                for s in negative_states:
                    if current_state == s:
                        raise StateWaitError(
                            'Failure state detected while waiting: {}={}'.format(attribute, current_state))
            if tot_wait >= max_wait:
                raise StateWaitError('Timeout {}sec reached while waiting'.format(max_wait))
            logging.debug(
                'Waiting not yet complete: {}={} (waiting {}/{})'.format(attribute, current_state, tot_wait, max_wait))
            time.sleep(iter_wait)
            tot_wait += iter_wait
            object_ = poll_method(object_)
            if object_ is None:
                raise StateWaitError(
                    'Object no longer exists: {}'.format(object_org))
            current_state = getattr(object_, attribute)
        logging.debug(
            'Waiting complete "{}" became "{}" in: {} (took: {}/{})'.format(attribute, expected_state, object_,
                                                                            tot_wait, max_wait))
        return object_
