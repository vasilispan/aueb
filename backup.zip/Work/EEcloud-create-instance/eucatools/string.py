
def _format_datapair(key, value, separator='='):
    return '{}{}{}'.format(key, separator, value)


def format_object_string(data, prefix='<', title='', title_separator='', value_separator='=', field_separator=', ', suffix='>'):
    data_strings = []
    for name, value in data:
        if isinstance(value, list):
            data_strings.append(_format_datapair(name, [str(o) for o in value], value_separator))
        else:
            data_strings.append(_format_datapair(name, value, value_separator))
    return prefix + title + title_separator + field_separator.join(data_strings) + suffix
