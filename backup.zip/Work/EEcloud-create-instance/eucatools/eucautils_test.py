import unittest

import mock
from mock import call

from eucatools.eucautils import EucaUtils, StateWaitError
from eucatools.object.base import ParseError
from eucatools.testutils.fake_euca_response import *
from eucatools.testutils.fake_object import create_fake_instance
from eucatools.testutils.validate import assert_attrs, assert_tags
from ciutils.executor import Executor


class CreateInstanceTest(unittest.TestCase):

    def setUp(self):
        self.kwargs = dict(image='test-image',
                           instance_type='test-instance',
                           pre_configured_key='test-key',
                           security_group='test-group',
                           az='test-az',
                           user_data='test-user-data')

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_success_immediate(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_instance_running(),
                                create_tag()]
        i = EucaUtils().create_instance(max_wait=0, **self.kwargs)
        self.assertEqual(i.id, 'i-3288af51')
        self.assertEqual(len(i.tags), 0)
        self.assertEqual(mock_run.call_args_list, [call('euca-run-instances -g test-group -k test-key -t test-instance -z test-az -f test-user-data test-image'),
                                                   call('euca-create-tags --tag OS=test-image i-3288af51')])
        self.assertEqual(mock_sleep.call_count, 0)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_success_tagged(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_instance_running(),
                                create_tag(),
                                create_tag(),
                                create_tag()]
        i = EucaUtils().create_instance(name='test-name', tags={'test-tag': 'test-value'}, **self.kwargs)
        self.assertEqual(i.id, 'i-3288af51')
        self.assertEqual(len(i.tags), 0)
        self.assertEqual(mock_run.call_args_list, [call('euca-run-instances -g test-group -k test-key -t test-instance -z test-az -f test-user-data test-image'),
                                                   call('euca-create-tags --tag test-tag=test-value --tag OS=test-image --tag Name=test-name i-3288af51')])
        self.assertEqual(mock_sleep.call_count, 0)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_success_slow(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_instance_pending(),
                                create_tag(),
                                describe_instance_pending(),
                                describe_instance_running()]
        i = EucaUtils().create_instance(**self.kwargs)
        self.assertEqual(i.id, 'i-c67d67e7')
        self.assertEqual(mock_run.call_args_list,
                         [call('euca-run-instances -g test-group -k test-key -t test-instance -z test-az -f test-user-data test-image'),
                          call('euca-create-tags --tag OS=test-image i-c67d67e7'),
                          call('euca-describe-instances i-c67d67e7'),
                          call('euca-describe-instances i-c67d67e7')])
        self.assertEqual(mock_sleep.call_count, 2)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_timeout(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_instance_pending(),
                                create_tag(),
                                describe_instance_pending(),
                                describe_instance_pending()]
        self.assertRaisesRegexp(
            StateWaitError, '.*Timeout.*', EucaUtils().create_instance, max_wait=6, **self.kwargs)
        self.assertEqual(len(mock_run.call_args_list), 4)
        self.assertEqual(mock_sleep.call_count, 2)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_fail_terminated(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_instance_pending(),
                                create_tag(),
                                describe_instance_terminated()]
        self._test_fail(mock_run, 'terminated')

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_fail_shuttingdown(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_instance_pending(),
                                create_tag(),
                                describe_instance_shuttingdown()]
        self._test_fail(mock_run, 'shutting-down')

    def _test_fail(self, mock_run, failure_state):
        self.assertRaisesRegexp(StateWaitError, '.*Failure state detected.*{}.*'.format(failure_state),
                                EucaUtils().create_instance, max_wait=6, **self.kwargs)


class DescribeInstancesTest(unittest.TestCase):

    @mock.patch.object(Executor, '_execute')
    def test_describe_instances_no_input(self, mock_run):
        mock_run.side_effect = [describe_instance_multiple()]
        instances = EucaUtils().describe_instances()
        mock_run.assert_called_once_with('euca-describe-instances')
        self.assertEqual(len(instances), 2)
        assert_attrs(instances[0], id='i-0d670729')
        assert_tags(instances[0], [('Name', 'maaniemi')])
        assert_attrs(instances[1], id='i-b12cb8e5')
        assert_tags(instances[1], [('Name', 'mikkosmtp'), ('type', 'private_server')])

    @mock.patch.object(Executor, '_execute')
    def test_describe_instances_input(self, mock_run):
        mock_run.side_effect = [describe_instance_multiple()]
        EucaUtils().describe_instances(['fake-id', 'fake-id2'])
        mock_run.assert_called_once_with('euca-describe-instances fake-id fake-id2')

    @mock.patch.object(Executor, '_execute')
    def test_describe_user_active_instances(self, mock_run):
        mock_run.side_effect = [describe_instance_multiple_for_same_user(),
                                describe_instance_multiple_for_same_user()]
        instances = EucaUtils().describe_user_active_instances('maaniemi')
        self.assertEqual(len(instances), 2)
        self.assertEqual(instances[0].id, 'i-0d670729')
        self.assertEqual(instances[1].id, 'i-b12cb8e5')
        instances = EucaUtils().describe_user_active_instances('non-existing-user')
        self.assertEqual(len(instances), 0)

    @mock.patch.object(Executor, '_execute')
    def test_describe_instance(self, mock_run):
        mock_run.side_effect = [describe_instance_running()]
        EucaUtils().describe_instance('fake-id')
        mock_run.assert_called_once_with('euca-describe-instances fake-id')

    @mock.patch.object(Executor, '_execute')
    def test_describe_instance_by_ip(self, mock_run):
        mock_run.side_effect = [describe_instance_multiple()]
        i = EucaUtils().describe_instance_by_ip('10.39.39.231')
        mock_run.assert_called_once_with('euca-describe-instances')
        assert_attrs(i, ip='10.39.39.231')


class CreateTagTest(unittest.TestCase):

    @mock.patch.object(Executor, '_execute')
    def test_create_tag(self, mock_run):
        mock_run.side_effect = [create_tag()]
        t = EucaUtils().create_tag('i-3288af51', 'ci-service', 'test-server')
        assert_attrs(t, id='i-e737b2fb', key='ci-service', value='test-server')
        mock_run.assert_called_once_with('euca-create-tags --tag ci-service=test-server i-3288af51')

    @mock.patch.object(Executor, '_execute')
    def test_create_tags(self, mock_run):
        mock_run.side_effect = [create_tags()]
        tags = EucaUtils().create_tags('i-3288af51', {'tag1': 'val1', 'tag2': None})
        mock_run.assert_called_once_with('euca-create-tags --tag tag1=val1 --tag tag2 i-3288af51')
        self.assertEqual(len(tags), 2)


class CreateVolumeTest(unittest.TestCase):

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_create(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_volume(),
                                describe_volume_creating(),
                                describe_volume_available()]
        v = EucaUtils().create_volume('test-az', size=1, max_wait=2)
        self.assertEqual(mock_run.call_args_list, [call('euca-create-volume -z test-az -s 1'),
                                                   call('euca-describe-volumes vol-4f3d5231'),
                                                   call('euca-describe-volumes vol-4f3d5231')])
        assert_attrs(v, id='vol-4f3d5231',
                     state='available',
                     size=50,
                     az='esclor84_1',
                     tags=[])
        self.assertEqual(mock_sleep.call_count, 2)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_create_named_volume(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_volume(),
                                create_tag(),
                                describe_volume_creating_tagged(),
                                describe_volume_available_tagged()]
        v = EucaUtils().create_volume('test-az', size=1, name='test-name', max_wait=2)
        mock_run.assert_has_calls([call('euca-create-tags --tag Name=test-name vol-4f3d5231')])
        assert_tags(v, [('Name', 'sakutest')])

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_create_from_snapshot(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_volume(),
                                create_tag(),
                                describe_volume_creating_tagged(),
                                describe_volume_available_tagged()]
        v = EucaUtils().create_volume('test-az', snapshot_id='test-snap', name='test-name', max_wait=2)
        mock_run.assert_has_calls([call('euca-create-volume -z test-az --snapshot test-snap')])
        assert_tags(v, [('Name', 'sakutest')])


class DescribeVolumesTest(unittest.TestCase):

    @mock.patch.object(Executor, '_execute')
    def test_describe_volumes_no_input(self, mock_run):
        mock_run.side_effect = [describe_volumes()]
        volumes = EucaUtils().describe_volumes()
        mock_run.assert_called_once_with('euca-describe-volumes')
        self.assertEqual(len(volumes), 3)

        assert_attrs(volumes[0], id='vol-ed4ef53a', size=10, az='esclor84_1', state='available', is_attached=False)
        assert_tags(volumes[0], [('Name', 'antti volume')])

        assert_attrs(volumes[1], id='vol-d7471216', size=50, az='esclor84_1', state='creating', is_attached=False)
        assert_tags(volumes[1], [])

        assert_attrs(volumes[2], id='vol-b594a024', size=15, az='esclor84_1', state='in-use', is_attached=True)
        assert_tags(volumes[2], [('Name', 'f1cheng')])
        assert_attrs(volumes[2].attachment, instance_id='i-3647d4f0',
                     volume_id='vol-b594a024', device='/dev/vdc', state='attached')

    @mock.patch.object(Executor, '_execute')
    def test_describe_volumes_input(self, mock_run):
        mock_run.side_effect = [describe_volumes()]
        _ = EucaUtils().describe_volumes(['fake-id'])
        mock_run.assert_called_once_with('euca-describe-volumes fake-id')

    @mock.patch.object(Executor, '_execute')
    def test_describe_user_volumes(self, mock_run):
        mock_run.side_effect = [describe_volumes(),
                                describe_volumes()]
        volumes = EucaUtils().describe_user_volumes('schydeni')
        self.assertEqual(len(volumes), 0)
        volumes = EucaUtils().describe_user_volumes('f1cheng')
        self.assertEqual(len(volumes), 1)


class CreateSnapshotTest(unittest.TestCase):

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_create(self, mock_run, mock_sleep):
        mock_run.side_effect = [create_snapshot(),
                                describe_snapshot_pending_tagged(),
                                describe_snapshot_completed_tagged()]
        s = EucaUtils().create_snapshot('test-volume-id', description='test-desc')
        self.assertEqual(mock_run.call_args_list, [call('euca-create-snapshot -d "test-desc" test-volume-id'),
                                                   call('euca-describe-snapshots snap-1b1ce45e'),
                                                   call('euca-describe-snapshots snap-1b1ce45e')])
        assert_attrs(s, id='snap-1b1ce45e',
                     volume_id='vol-37f95d99',
                     state='completed')
        assert_tags(s, [('Name', 'dev-schydeni'), ('dev-temporary', None)])
        self.assertEqual(mock_sleep.call_count, 2)


class DeleteSnapshotTest(unittest.TestCase):

    @mock.patch.object(Executor, '_execute')
    def test_delete(self, mock_run):
        mock_run.side_effect = [delete_snapshot(),
                                describe_snapshots()]
        EucaUtils().delete_snapshot('snapshot-id')
        self.assertEqual(mock_run.call_args_list, [call('euca-delete-snapshot snapshot-id'),
                                                   call('euca-describe-snapshots')])


class DescribeSanpshotsTest(unittest.TestCase):

    @mock.patch.object(Executor, '_execute')
    def test_describe_snapshots_no_input(self, mock_run):
        mock_run.side_effect = [describe_snapshots()]
        snapshots = EucaUtils().describe_snapshots()
        mock_run.assert_called_once_with('euca-describe-snapshots')
        self.assertEqual(len(snapshots), 2)

        assert_attrs(snapshots[0], id='snap-1b1ce45e', volume_id='vol-37f95d99', state='completed')
        assert_tags(snapshots[0], [('Name', 'dev-schydeni'), ('dev-temporary', None)])

        assert_attrs(snapshots[1], id='snap-f75afe0c', volume_id='vol-ca101461', state='completed')
        assert_tags(snapshots[1], [('Name', 'Snap1')])

    @mock.patch.object(Executor, '_execute')
    def test_describe_snapshots_empty_response(self, mock_run):
        mock_run.side_effect = [empty_response()]
        snapshots = EucaUtils().describe_snapshots()
        mock_run.assert_called_once_with('euca-describe-snapshots')
        self.assertEqual(len(snapshots), 0)


class AttachVolumeTest(unittest.TestCase):

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_attach(self, mock_run, mock_sleep):
        mock_run.side_effect = [attach_volume(),
                                describe_volume_attaching(),
                                describe_volume_attached(),
                                describe_volume_attached()]
        v = EucaUtils().attach_volume('instance-id', '/dev/vdc', 'volume-id', max_wait=2)
        self.assertEqual(mock_run.call_args_list, [call('euca-attach-volume -i instance-id -d /dev/vdc volume-id'),
                                                   call('euca-describe-volumes volume-id'),
                                                   call('euca-describe-volumes vol-4f3d5231'),
                                                   call('euca-describe-volumes vol-4f3d5231')])
        assert_attrs(v, state='in-use', id='vol-4f3d5231')
        assert_attrs(v.attachment, state='attached', volume_id='vol-4f3d5231',
                     instance_id='i-c67d67e7', device='/dev/vdc')
        self.assertEqual(mock_sleep.call_count, 2)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_attach_fails_to_attach(self, mock_run, mock_sleep):
        mock_run.side_effect = mock_run.side_effect = [attach_volume(),
                                                       describe_volume_attaching(),
                                                       describe_volume_available()]
        self.assertRaisesRegexp(StateWaitError, 'Object no longer exists',
                                EucaUtils().attach_volume, 'instance-id', '/dev/vdc', 'volume-id', max_wait=2)
        self.assertEqual(mock_sleep.call_count, 1)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_attach_commad_fail(self, mock_run, mock_sleep):
        mock_run.side_effect = mock_run.side_effect = [attach_volume_fail_inuse()]
        self.assertRaisesRegexp(Exception, 'Volume already attached',
                                EucaUtils().attach_volume, 'instance-id', 'device', 'volume-id', max_wait=2)


class DetachVolumeTest(unittest.TestCase):

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, '_execute')
    def test_detach(self, mock_run, mock_sleep):
        mock_run.side_effect = [describe_volume_attached(),
                                detach_volume(),
                                describe_volume_detaching(),
                                describe_volume_available()]
        v = EucaUtils().detach_volume('instance-id', 'volume-id', max_wait=2)
        self.assertEqual(mock_run.call_args_list, [call('euca-describe-volumes volume-id'),
                                                   call('euca-detach-volume -i instance-id volume-id'),
                                                   call('euca-describe-volumes vol-4f3d5231'),
                                                   call('euca-describe-volumes vol-4f3d5231')])
        assert_attrs(v, state='available', id='vol-4f3d5231', attachment=None)
        self.assertEqual(mock_sleep.call_count, 2)


if __name__ == "__main__":
    unittest.main()
