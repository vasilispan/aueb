import unittest
from mock import call
import mock

from eucatools.eucarc import EucarcReader
from eucatools.testutils.fake_executor_result import _create_success_result
from ciutils.executor import Executor


fake_env = '''EC2_JVM_ARGS=-test=/home/schydeni/
EC2_USER_ID=foo
EC2_URL=http://bar:8773/
'''


class SiteConfigTest(unittest.TestCase):

    @mock.patch('os.environ')
    @mock.patch.object(Executor, '_execute')
    def test_rc_is_set_to_env(self, mock_exec, mock_os):
        mock_exec.side_effect = [_create_success_result(fake_env)]
        EucarcReader('fake/eucarc').source_eucarc()
        mock_exec.assert_called_once_with('env -i bash -c ". fake/eucarc && env"')
        self.assertEqual(mock_os.mock_calls, [call.__setitem__('EC2_JVM_ARGS', '-test=/home/schydeni/'),
                                              call.__setitem__('EC2_USER_ID', 'foo'),
                                              call.__setitem__('EC2_URL', 'http://bar:8773/')])

if __name__ == "__main__":
    unittest.main()
