import unittest
import os
import mock

from eucatools.script.create_base import CreateBase

from eucatools.testutils.fake_site import get_default_config, get_modified_config


@mock.patch('__builtin__.open', create=True)
class CreateBaseTest(unittest.TestCase):

    def setUp(self):
        self.default_args = {}

    def test_default_config(self, mock_open):
        mock_open.return_value.readline.side_effect = get_default_config()
        base = CreateBase(self.default_args)
        self.assertEqual(base.smtp_server, 'mailrelay.int.nokia.com')
        self.assertEqual(base.admin_emails, ['no.admin@configured'])

    def test_modified_config(self, mock_open):
        mock_open.return_value.readline.side_effect = get_modified_config()
        base = CreateBase(self.default_args)
        self.assertEqual(base.smtp_server, 'test-snmp-server')
        self.assertEqual(base.admin_emails, ['admin1-email'])



if __name__ == "__main__":
    unittest.main()
