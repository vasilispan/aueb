import os

from ciutils.log import LogConfig
from ciutils.ddns import DDNSUpdate

from eucatools.eucarc import EucarcReader
from eucatools.eucautils import EucaUtils
from eucatools.site import SiteConfig


class CreateBase(object):

    ddns_server = 'dynamic.nsn-net.net'
    blockdevice = '/dev/vdc'
    instance_type = 'm1.small'
    volume_size = 10
    root_password = 'System#1'  # NOTE: hardcoded on ansible side

    def __init__(self, args):
        LogConfig.initialize()
        self.e = EucaUtils()
        self.args = args
        self.siteconfig = SiteConfig()
        EucarcReader(self.ee_eucarc).source_eucarc()

    @property
    def private_key(self):
        return os.path.realpath(os.path.expanduser(self.siteconfig.ee['private-key-file']))

    @property
    def ee_eucarc(self):
        return os.path.realpath(os.path.expanduser(self.siteconfig.ee['eucarc']))

    @property
    def ee_az(self):
        return self.siteconfig.ee['az']

    @property
    def ee_keypair_name(self):
        return self.siteconfig.ee['keypair']

    @property
    def ee_security_group(self):
        return self.siteconfig.ee['security-group']

    @property
    def smtp_server(self):
        return self.siteconfig.email.get('smtp-server', 'mailrelay.int.nokia.com')

    @property
    def http_proxy(self):
        return self.siteconfig.intranet['http-proxy']

    @property
    def admin_emails(self):
        admins = self.siteconfig.email.get('admins')
        if admins:
            return admins.split(',')
        return ['no.admin@configured']

    def run(self):
        self._run()

    def resolve_image_id(self, image_name):
        return self.siteconfig.ee_images.get(image_name, image_name)

    def _update_ddns(self, ip, name):
        DDNSUpdate(ip, name, ddns_server=self.ddns_server).run()