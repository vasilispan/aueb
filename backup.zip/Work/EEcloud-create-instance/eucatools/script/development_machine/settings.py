
tags = {'type': 'private_server'}
