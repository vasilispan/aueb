import unittest

from mock import call
import mock

from eucatools.script.development_machine import create
import eucatools.script.development_machine.create
from eucatools.testutils.fake_object import *
from eucatools.testutils.validate import assert_calls


from eucatools.testutils.fake_site import get_modified_config

mandatory_args = ['--user-id', 'schydeni']
user_email_args = ['--user-email', 'test@mail.com']
call_create_instance = call.create_instance(
    instance_type='m1.small', image='i-fake-image', az='esclor86_2', name='schydeni',
    tags={'type': 'private_server'}, security_group='default', pre_configured_key='cloudman')
call_describe_instances = call.describe_user_active_instances('schydeni')
call_create_volume = call.create_volume('esclor86_2', tags={'type': 'private_server'}, name='schydeni', size=10)
call_describe_volumes = call.describe_user_volumes('schydeni')
call_attach_volume = call.attach_volume('i-c67d67e7', '/dev/vdc', 'vol-4f3d5231')


@mock.patch('eucatools.script.create_base.EucarcReader')
@mock.patch('eucatools.script.development_machine.create.TargetUtils')
@mock.patch('eucatools.script.development_machine.create.AnsibleRunner')
@mock.patch('eucatools.script.create_base.DDNSUpdate')
@mock.patch.object(eucatools.script.development_machine.create.Mailer, 'send_mail')
@mock.patch('eucatools.script.create_base.EucaUtils')
class DefaultBehaviourTest(unittest.TestCase):

    def setUp(self):
        _setup_default_site_config(self)

    def test_unexpected_error(self, m, mock_mail, *_):
        m.return_value.describe_user_active_instances.side_effect = [Exception(unexpected_exception_str)]
        self.assertRaisesRegexp(
            Exception, 'EECloud server create FAILED - UNEXPECTED ERROR', create.main, mandatory_args)
        _validate_failure_mail(self, mock_mail, 'EECloud server create FAILED - UNEXPECTED ERROR',
                               expected_body_re='Command "euca-describe-volumes" execution status NOT zero',
                               expected_to='admin1-email', expected_cc=None)

    def test_create_with_no_existing_volume(self, m, mock_mail, mock_ddns, *_):
        self._test_create_both(mandatory_args, m, [], [])
        _validate_no_mail(self, mock_mail)
        _validate_ddns_update(mock_ddns)

    def test_email_is_sent_to_user_if_given(self, m, mock_mail, *_):
        self._test_create_both(mandatory_args + user_email_args, m, [], [])
        _validate_create_mail(self, mock_mail)

    def test_create_from_existing_volume(self, m, mock_mail, *_):
        self._test_create_from_old_volume(mandatory_args, m, [], [get_fake_volume()])
        _validate_no_mail(self, mock_mail)
        self._test_create_from_old_volume(mandatory_args + user_email_args, m, [], [get_fake_volume()])
        _validate_create_mail(self, mock_mail)

    def test_user_has_too_many_instances(self, m, mock_mail, *_):
        self._test_user_has_too_many_instances(mandatory_args, m, mock_mail, [])
        _validate_failure_mail(self, mock_mail, 'EECloud server create FAILED - Too many user instances',
                               expected_body_re='shutdown -h now')
        self._test_user_has_too_many_instances(mandatory_args, m, mock_mail, [get_fake_volume()])
        _validate_failure_mail(self, mock_mail, 'EECloud server create FAILED - Too many user instances',
                               expected_body_re='shutdown -h now')

    def test_failure_email_is_sent_to_admin(self, m, mock_mail, *_):
        self._test_user_has_too_many_instances(mandatory_args, m, mock_mail, [])
        _validate_failure_mail(self, mock_mail, 'EECloud server create FAILED - Too many user instances',
                               expected_to='admin1-email', expected_cc=None)
        self._test_user_has_too_many_instances(mandatory_args + user_email_args, m, mock_mail, [])
        _validate_failure_mail(self, mock_mail, 'EECloud server create FAILED - Too many user instances',
                               expected_to='test@mail.com', expected_cc=['admin1-email'])

    def _test_user_has_too_many_instances(self, args, m, mock_mail, volumes):
        _setup_default_site_config(self)
        m.reset_mock()
        mock_mail.reset_mock()
        m.return_value.describe_user_active_instances.side_effect = [[get_fake_instance(), get_fake_instance()]]
        m.return_value.describe_user_volumes.side_effect = [volumes]
        self.assertRaisesRegexp(
            create.EnvironmentCreateFailed, 'Too many user instances', create.main, args)
        expected_calls = [call_describe_volumes,
                          call_describe_instances]
        assert_calls(m.return_value.method_calls, expected_calls)

    def test_user_has_too_many_volumes(self, m, mock_mail, *_):
        self._test_user_has_too_many_volumes(m, mock_mail)

    def _test_user_has_too_many_volumes(self, m, mock_mail):
        _setup_default_site_config(self)
        m.reset_mock()
        mock_mail.reset_mock()
        m.return_value.describe_user_volumes.side_effect = [[get_fake_volume(), get_fake_volume()]]
        self.assertRaisesRegexp(
            create.EnvironmentCreateFailed, 'Too many user volumes', create.main, mandatory_args)
        _validate_failure_mail(self, mock_mail, 'EECloud server create FAILED - Too many user volumes')
        expected_calls = [call_describe_volumes]
        assert_calls(m.return_value.method_calls, expected_calls)

    def _test_create_both(self, args, mock_euca, active_instances, active_volumes):
        _setup_default_site_config(self)
        mock_euca.reset_mock()
        mock_euca.return_value.describe_user_active_instances.side_effect = [active_instances]
        mock_euca.return_value.describe_user_volumes.side_effect = [active_volumes]
        mock_euca.return_value.create_instance.side_effect = [get_fake_instance()]
        mock_euca.return_value.create_volume.side_effect = [get_fake_volume()]
        create.main(args)
        expected_calls = [call_describe_volumes,
                          call_describe_instances,
                          call_create_instance,
                          call_create_volume,
                          call_attach_volume]
        assert_calls(mock_euca.return_value.method_calls, expected_calls)

    def _test_create_from_old_volume(self, args, mock_euca, active_instances, active_volumes):
        _setup_default_site_config(self)
        mock_euca.reset_mock()
        mock_euca.return_value.describe_user_active_instances.side_effect = [active_instances]
        mock_euca.return_value.describe_user_volumes.side_effect = [active_volumes]
        mock_euca.return_value.create_instance.side_effect = [get_fake_instance()]
        mock_euca.return_value.create_snapshot.side_effect = [get_fake_snapshot()]
        mock_euca.return_value.create_volume.side_effect = [get_fake_volume()]
        create.main(args)
        expected_calls = [call_describe_volumes,
                          call_describe_instances,
                          call_create_instance,
                          call_attach_volume]
        assert_calls(mock_euca.return_value.method_calls, expected_calls)


@mock.patch('eucatools.script.create_base.DDNSUpdate')
@mock.patch('eucatools.script.create_base.EucarcReader')
@mock.patch('eucatools.script.development_machine.create.TargetUtils')
@mock.patch.object(eucatools.script.development_machine.create.Mailer, 'send_mail')
@mock.patch('eucatools.script.development_machine.create.AnsibleRunner')
@mock.patch('eucatools.script.create_base.EucaUtils')
class ArgumentTest(unittest.TestCase):

    def setUp(self):
        _setup_default_site_config(self)
        self.args = mandatory_args + ['--user-email', 'test@mail.com']
        self.call_describe_instances = call.describe_user_active_instances('test-user')
        self.call_describe_volumes = call.describe_user_volumes('test-user')
        self.call_create_instance = call.create_instance(
            instance_type='m1.small', image='i-fake-image', az='esclor86_2', name='test-user',
            tags={'type': 'private_server'}, security_group='default', pre_configured_key='cloudman')
        self.call_create_volume = call.create_volume(
            'esclor86_2', tags={'type': 'private_server'}, name='test-user', size=10)
        self.call_attach_volume = call.attach_volume('i-c67d67e7', '/dev/vdc', 'vol-4f3d5231')

    def test_extra_instance_args(self, mock_euca, *_):
        mock_euca.return_value.describe_user_active_instances.side_effect = [[]]
        mock_euca.return_value.describe_user_volumes.side_effect = [[]]
        mock_euca.return_value.create_instance.side_effect = [get_fake_instance()]
        mock_euca.return_value.create_volume.side_effect = [get_fake_volume()]
        create.main(
            self.args + ['--test-user-id', 'test-user', '--instance-type', 'm1.large.test', '--os', 'my-os-id', '--volume-size', '50'])
        expected_calls = [self.call_describe_volumes,
                          self.call_describe_instances,
                          call.create_instance(instance_type='m1.large.test', image='my-os-id', az='esclor86_2',
                                               name='test-user', tags={'type': 'private_server'},
                                               security_group='default', pre_configured_key='cloudman'),
                          call.create_volume('esclor86_2', tags={'type': 'private_server'}, name='test-user', size=50),
                          self.call_attach_volume]
        assert_calls(mock_euca.return_value.method_calls, expected_calls)

    def test__test_user_id__is_used_in_euca_side_only(self, mock_euca, mock_ansible, *_):
        mock_euca.return_value.describe_user_active_instances.side_effect = [[]]
        mock_euca.return_value.describe_user_volumes.side_effect = [[]]
        mock_euca.return_value.create_instance.side_effect = [get_fake_instance()]
        mock_euca.return_value.create_volume.side_effect = [get_fake_volume()]
        create.main(self.args + ['--test-user-id', 'test-user'])
        expected_calls = [self.call_describe_volumes,
                          self.call_describe_instances,
                          self.call_create_instance,
                          self.call_create_volume,
                          self.call_attach_volume]
        assert_calls(mock_euca.return_value.method_calls, expected_calls)
        self.assertEqual(
            mock_ansible.return_value.method_calls, [call.create_devel_env('schydeni', base_image_only=False)])

    def test__ansible_only__skips_euca_stuff(self, mock_euca, mock_ansible, mock_mail, *_):
        mock_euca.return_value.describe_instance_by_ip.side_effect = [get_fake_instance()]
        create.main(self.args + ['--ansible-only', '1.2.3.4'])
        self.assertEqual(
            mock_euca.return_value.method_calls, [call.describe_instance_by_ip('1.2.3.4')])
        self.assertEqual(
            mock_ansible.return_value.method_calls, [call.create_devel_env('schydeni', base_image_only=False)])
        _validate_refresh_mail(self, mock_mail)

    def test__ansible_only__fails_if_user_id_mismatch_with_instance(self, mock_euca, mock_ansible, mock_mail, *_):
        mock_euca.return_value.describe_instance_by_ip.side_effect = [get_fake_instance()]
        args = ['--user-id', 'non-matching-id']
        self.assertRaisesRegexp(
            create.EnvironmentCreateFailed, 'User id mismatch',
            create.main, args + ['--ansible-only', '1.2.3.4'])
        self.assertEqual(
            mock_euca.return_value.method_calls, [call.describe_instance_by_ip('1.2.3.4')])
        self.assertEqual(
            mock_ansible.return_value.method_calls, [])
        _validate_failure_mail(self, mock_mail, 'EECloud server create FAILED - User id mismatch')


def _setup_default_site_config(testcase):
    patcher = mock.patch('__builtin__.open', create=True)
    mocked_open = patcher.start()
    mocked_open.return_value.readline.side_effect = get_modified_config()
    testcase.addCleanup(patcher.stop)


def _validate_no_mail(testcase, mock_mail):
    testcase.assertEqual(mock_mail.call_count, 0)


def _validate_ddns_update(mock_ddns):
    mock_ddns.assert_called_once_with('10.39.39.145', 'schydeni.zoo', ddns_server='dynamic.nsn-net.net')


def _validate_create_mail(testcase, mock_mail):
    testcase.assertEqual(mock_mail.call_count, 1)
    testcase.assertEqual(mock_mail.call_args[0][0], 'EECloud-instance-create')
    testcase.assertEqual(mock_mail.call_args[0][1], ['test@mail.com'])
    testcase.assertEqual(mock_mail.call_args[0][2], 'EECloud server CREATED')
    testcase.assertEqual(mock_mail.call_args[1]['cc'], None)
    email_body_strings = ['DNS: euca-10-39-39-145.eucalyptus.esclor84.eecloud.nsn-rdnet.net',
                          'IP: 10.39.39.145',
                          'VNC: schydeni.zoo.dynamic.nsn-net.net:99',
                          '/home/schydeni - PERSISTENT',
                          '/ephemeral/schydeni - NON-PERSISTENT',
                          'share for files is under: http://schydeni.zoo.dynamic.nsn-net.net/~schydeni',
                          r'Map a network drive with: \\\\schydeni.zoo.dynamic.nsn-net.net\\schydeni']
    for s in email_body_strings:
        testcase.assertRegexpMatches(mock_mail.call_args[0][3], s)


def _validate_failure_mail(testcase, mock_mail, subject, expected_body_re=None, expected_to='admin1-email', expected_cc=None):
    testcase.assertEqual(mock_mail.call_count, 1)
    testcase.assertEqual(mock_mail.call_args[0][1], [expected_to])
    testcase.assertEqual(mock_mail.call_args[0][2], subject)
    if expected_body_re is not None:
        testcase.assertRegexpMatches(mock_mail.call_args[0][3], expected_body_re)
    testcase.assertEqual(mock_mail.call_args[1]['cc'], expected_cc)


def _validate_refresh_mail(testcase, mock_mail):
    testcase.assertEqual(mock_mail.call_count, 1)
    testcase.assertEqual(mock_mail.call_args[0][0], 'EECloud-instance-create')
    testcase.assertEqual(mock_mail.call_args[0][1], ['test@mail.com'])
    testcase.assertEqual(mock_mail.call_args[0][2], 'EECloud server REFRESHED - latest configuration updated')
    testcase.assertEqual(mock_mail.call_args[1]['cc'], None)

unexpected_exception_str = '''EECloud server create FAILED - UNEXPECTED ERROR

Traceback (most recent call last):
  File "eucatools/script/development_machine/create.py", line 72, in run
    self._run()
  File "eucatools/script/development_machine/create.py", line 97, in _run
    self.instance = self._run_ee()
  File "eucatools/script/development_machine/create.py", line 107, in _run_ee
    self.prepare()
  File "eucatools/script/development_machine/create.py", line 57, in prepare
    self.user_existing_volumes = self.e.describe_user_volumes(self.ee_user)
  File "/home/schydeni/gitlab/common/eecloud-create-instance/eucatools/eucautils.py", line 144, in describe_user_volumes
    volumes = self._filter_by_name(user_id, self.describe_volumes())
  File "/home/schydeni/gitlab/common/eecloud-create-instance/eucatools/eucautils.py", line 121, in describe_volumes
    return self._describe_objects(EucaApi().describe_volumes, 'volumes', volume_ids)
  File "/home/schydeni/gitlab/common/eecloud-create-instance/eucatools/eucautils.py", line 192, in _describe_objects
    result = describe_method()
  File "/home/schydeni/gitlab/common/eecloud-create-instance/eucatools/eucaapi.py", line 51, in describe_volumes
    return self.e.run(cmd, retries=3, do_fail=True)
  File "/home/schydeni/gitlab/common/eecloud-create-instance/ciutils/executor.py", line 22, in run
    raise ExecutionError('Command "{}" execution status NOT zero: {}'.format(cmd, str(r)))
ExecutionError: Command "euca-describe-volumes" execution status NOT zero: Status:"0"
Stdout:"VOLUME    vol-a91b4766    10        esclor86_2    in-use    2016-02-12T15:11:28.167Z    standard    
ATTACHMENT    vol-a91b4766    i-b51b9c53    /dev/vdc    attached    2016-02-12T15:11:36.649Z
TAG    volume    vol-a91b4766    Name    gengler
TAG    volume    vol-a91b4766    type    private_server
VOLUME    vol-c70efff0    10        esclor86_2    in-use    2016-02-18T08:21:19.161Z    standard    
ATTACHMENT    vol-c70efff0    i-9e15358c    /dev/vdc    attached    2016-02-18T08:21:27.717Z
TAG    volume    vol-c70efff0    Name    karna
TAG    volume    vol-c70efff0    type    private_server
VOLUME    vol-2c741dad    10        esclor86_2    available    2016-02-17T14:52:40.543Z    standard    
TAG    volume    vol-2c741dad    Name    sonar-test
TAG    volume    vol-2c741dad    ci_service    sonar-test
VOLUME    vol-a5ad33ae    30        esclor86_2    in-use    2016-02-19T13:54:39.415Z    standard    
ATTACHMENT    vol-a5ad33ae    i-0808b7b8    /dev/vdc    attached    2016-02-19T13:54:47.100Z
TAG    volume    vol-a5ad33ae    Name    sonarqube
TAG    volume    vol-a5ad33ae    ci_service    sonarqube
VOLUME    vol-e0e4341e    10    snap-5283e882    esclor86_2    available    2016-02-10T11:55:27.991Z    standard    
TAG    volume    vol-e0e4341e    Name    sonar
VOLUME    vol-8702a52a    50        esclor86_2    in-use    2016-02-26T07:44:56.991Z    standard    
ATTACHMENT    vol-8702a52a    i-a4b24b25    /dev/vdc    attached    2016-02-26T07:47:27.254Z
TAG    volume    vol-8702a52a    Name    RBoard1
VOLUME    vol-5d43c6e5    10        esclor86_2    in-use    2016-02-29T13:16:23.575Z    standard    
ATTACHMENT    vol-5d43c6e5    i-a81e8ac5    /dev/vdc    attached    2016-02-29T13:16:27.571Z
TAG    volume    vol-5d43c6e5    Name    schydeni-test2
TAG    volume    vol-5d43c6e5    type    private_server
VOLUME    vol-57417549    10    snap-c7813c72    esclor86_2    in-use    2016-02-11T10:59:30.761Z    standard    
ATTACHMENT    vol-57417549    i-e09bb9ab    /dev/vdc    attached    2016-02-11T10:59:47.773Z
TAG    volume    vol-57417549    Name    schydeni
TAG    volume    vol-57417549    type    private_server
VOLUME    vol-83699835    150        esclor86_2    in-use    2016-01-29T07:12:59.351Z    standard    
ATTACHMENT    vol-83699835    i-89499c6b    /dev/vdc    attached    2016-01-29T07:13:16.870Z
TAG    volume    vol-83699835    Name    cici-vol
VOLUME    vol-72797b38    50        esclor86_2    in-use    2016-02-26T07:45:29.914Z    standard    
ATTACHMENT    vol-72797b38    i-f9383c2f    /dev/vdc    attached    2016-02-26T07:48:03.296Z
TAG    volume    vol-72797b38    Name    RBoard2
"
Stderr:""
'''

if __name__ == "__main__":
    unittest.main()
