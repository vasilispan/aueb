#!/bin/sh
#
# Tests that eecloud instance has been successfully created
#
set -e
set -x

if [ $# -ne 3 ]; then
  echo "usage: $0 <ip> <user> <pass>"
  exit 1
fi

export SSHPASS=$3
ip=$1
user_id=$2

_on_exit() {
  res=$?
  if [ $res -eq 0 ]; then
    _result SUCCESS
  else
    _result FAIL
  fi
  exit $res
}

trap _on_exit EXIT

_result() {
  echo "#############################################"
  echo "# $@"
  echo "#############################################"
}

_cmd() {
  sshpass -e ssh $ip -l $user_id $@
}

_test() {
  echo "### $@ ###"
}

_test login with root password
sshpass -p System#1 ssh $ip -l root true

_test login with user
_cmd true

_test home dir public share
_cmd touch ~/public_html/foo
wget http://$ip/~$user_id/foo -O /dev/null
_cmd rm -f ~/public_html/foo

_test sudo
_cmd sudo cat /etc/sudoers >/dev/null

_test smb
smbclient -U $user_id -L \\\\${ip}\\${user_id} -k | egrep "${user_id}\s*Disk"

_test installed pkgs
_cmd pip list installed | grep robotframework

_test user in mock group
_cmd id -Gn $user_id | grep mock

_test home dir
_cmd df | grep vdc | grep $user_id

_test repo
_cmd which repo

