import traceback
import argparse
import sys
import logging

from eucatools.exception import EECloudException
from eucatools.targetutils import TargetUtils
from eucatools.script.create_base import CreateBase
from eucatools.script.development_machine import settings

from ciutils.ansible import AnsibleRunner
from ciutils.mail import Mailer


class EnvironmentCreateFailed(EECloudException):
    def __init__(self, message, details):
        super(EECloudException, self).__init__(message)
        self.details = details

    def __str__(self):
        return '{}\n{}'.format(super(EECloudException, self).__str__(), self.details)

class CreateDev(CreateBase):
    def __init__(self, args):
        super(CreateDev, self).__init__(args)
        self.user_existing_volumes = []
        self.instance = None

    @property
    def user_id(self):
        return self.args.user_id

    @property
    def ee_user(self):
        if self.args.test_user_id is not None:
            return self.args.test_user_id
        return self.args.user_id

    @property
    def user_ddns(self):
        return '{}.zoo'.format(self.ee_user)

    @property
    def user_fqdn(self):
        return '{}.zoo.{}'.format(self.ee_user, self.ddns_server)

    #@property
    def user_volume_az(self):
        if self.e.describe_user_volumes_az(self.ee_user) :
            return self.e.describe_user_volumes_az(self.ee_user)
        else:
            return None

    @property
    def old_volume(self):
        if self.user_existing_volumes:
            return self.user_existing_volumes[0]
        return None

    def prepare(self):
        self.user_existing_volumes = self.e.describe_user_volumes(self.ee_user)
        self._validate_max_objects(
            self.user_existing_volumes,
            1,
            problem_title='Too many user volumes',
            corrective_action='Please contact admin to remove volume(s)')
        user_existing_instances = self.e.describe_user_active_instances(self.ee_user)
        self._validate_max_objects(
            user_existing_instances,
            0,
            problem_title='Too many user instances',
            corrective_action='\n'.join(['Please shut down existing instance(s) in order to create new one',
                                         'ssh root@<ip> "shutdown -h now" #default pw: {}'.format(self.root_password)]))

    def run(self):
        try:
            self._run()
        except EnvironmentCreateFailed as e:
            logging.error(str(e))
            self._send_error_mail(e.message, e.details)
            raise
        except Exception as e:
            logging.critical(str(e))
            self._send_error_mail('UNEXPECTED ERROR', traceback.format_exc(sys.exc_info()))
            raise

    def _run(self):
        if self.args.ip:
            self.instance = self.e.describe_instance_by_ip(self.args.ip)
            if self.instance.user_name != self.ee_user:
                raise EnvironmentCreateFailed(
                    'User id mismatch',
                    'User id given "{}" does not match the instance user: "{}" ({})'.format(self.ee_user,
                                                                                            self.instance.user_name,
                                                                                            self.instance))
        else:
            self.prepare()
            self.instance = self._run_ee()
        self._run_ansible(self.instance.ip)
        if not self.args.base_image_only and not self.args.test_user_id:
            self._update_ddns(self.instance.ip, self.user_ddns)
        if self.args.ip:
            self._send_completion_mail(self.instance.ip, self.instance.name,
                                       "EECloud server REFRESHED - latest configuration updated")
            logging.info(self._build_description_str('REFRESH'))
        else:
            self._send_completion_mail(self.instance.ip, self.instance.name, "EECloud server CREATED")
            logging.info(self._build_description_str('CREATE'))

    def _build_description_str(self, title):
        return 'SHORT_DESCRIPTION: [{}] {} --> id:{} ip:{}'.format(title, self.user_id, self.instance.id,
                                                                   self.instance.ip)

    def _run_ee(self):
        instance = self._run_create_instance()
        TargetUtils(instance.ip, self.private_key).wait_instance_up(instance)
        if not self.args.base_image_only:
            volume = self._run_create_volume()
            self.e.attach_volume(instance.id, self.blockdevice, volume.id)
        return instance

    def _validate_max_objects(self, objects, max_count, problem_title, corrective_action):
        if len(objects) > max_count:
            objects_str = '\n'.join([i.pretty for i in objects])
            raise EnvironmentCreateFailed(
                problem_title,
                '''max: {max}
actual: {actual}

{objects}

ACTION REQUIRED: {corrective_action}
'''.format(problem_title=problem_title,
           max=max_count,
           actual=len(objects),
           objects=objects_str,
           corrective_action=corrective_action))

    def _run_create_instance(self):
        if self.user_volume_az() is not None:
            print("using existing volume's az ")
            #print("User {} already has a volume in {} ".format(self.ee_user) , self.user_volume_az()[0])
            #az = self.user_volume_az()[0]
            instance = self.e.create_instance(
                name=self.ee_user, image=self.resolve_image_id(self.args.os), instance_type=self.args.instance_type,
                tags=settings.tags,
                az=self.user_volume_az()[0], pre_configured_key=self.ee_keypair_name, security_group=self.ee_security_group,
                max_wait=30 * 60)
        else:
            az = self.ee_az
            instance = self.e.create_instance(
                name=self.ee_user, image=self.resolve_image_id(self.args.os), instance_type=self.args.instance_type,
                tags=settings.tags,
                az=self.ee_az, pre_configured_key=self.ee_keypair_name, security_group=self.ee_security_group,
                max_wait=30*60)
        return instance

    def _run_create_snapshot(self, volume_id):
        return self.e.create_snapshot(volume_id, name=self.ee_user, tags={'tmp_volume_create': None})

    def _run_delete_snapshot(self, snapshot_id):
        return self.e.delete_snapshot(snapshot_id)

    def _run_create_volume(self):
        if self.old_volume:
            return self.old_volume
        return self.e.create_volume(self.ee_az, tags=settings.tags, name=self.ee_user, size=self.args.volume_size)

    def _run_ansible(self, ip):
        AnsibleRunner(ip, self.private_key).create_devel_env(self.user_id, base_image_only=self.args.base_image_only)

    def _send_mail(self, to, subject, body, ip=None, dns_name=None, cc=None, format_body=True):
        if format_body:
            body = body.format(subject=subject,
                               root_password=self.root_password,
                               user_fqdn=self.user_fqdn,
                               instance_ip=ip,
                               instance_name=dns_name,
                               instance_vnc='{}:99'.format(self.user_fqdn),
                               user_smb_path=r'\\{}\{}'.format(self.user_fqdn, self.args.user_id),
                               user_home_dir='/home/{}'.format(self.args.user_id),
                               user_ephemeral_dir='/ephemeral/{}'.format(self.args.user_id),
                               user_id=self.args.user_id)
        Mailer(self.smtp_server).send_mail(
            'EECloud-instance-create', to, subject, body, cc=cc)

    def _send_error_mail(self, subject, body):
        subject = "EECloud server create FAILED - {}".format(subject)
        body = r'''{subject}

{body}
'''.format(subject=subject,
           body=body)
        if self.args.user_email is not None:
            to = [self.args.user_email]
            cc = self.admin_emails
        elif self.admin_emails:
            to = self.admin_emails
            cc = None
        else:
            return
        self._send_mail(to, subject, body, cc=cc, format_body=False)

    def _send_completion_mail(self, ip, dns_name, subject):
        body = r'''{subject}

DNS: {instance_name}
DDNS: {user_fqdn} (NOTE! takes some minutes to register)
IP: {instance_ip}
VNC: {instance_vnc}

To login:
 - ssh {user_id}@{user_fqdn}
    - intranet password
    - has sudo rights
    - NOTE: intra authentication may not work at all times, login as root should work all the time
 - ssh root@{user_fqdn}
    - Default root password: {root_password}
    - change with: passwd
 - vncviewer {instance_vnc}
    - Default VNC password: password
    - change with: vncpasswd


### About the instance ###

* The instance is *NOT* persistent
   - shutting down the instance destroys it: "shutdown -h now"
   - rebooting the instance does NOT destroy it: "reboot now"


### About the disk space ###

The only persistent directory is {user_home_dir}. 
Any other files are **NOT** persistent and lost when instance is shut down.

Two main work spaces:
* {user_home_dir} - PERSISTENT
* {user_ephemeral_dir} - NON-PERSISTENT !!!


### Misc ###

* The instance does *NOT* know it's own external IP
* Most of the ports are blocked in company intranet
   - e.g. 8080 is open
* Public share for files is under: http://{user_fqdn}/~{user_id}


### Optional Post Steps ###

1. Assign an additional DDNS name
   - Check the name does *NOT* exist already: "host <desired-name>.dynamic.nsn-net.net"
   - Execute: "sudo /root/script/ddns_update.sh {instance_ip} <desired-name>"
   - Should take some minutes to register

2. Mount home directory to windows
   - Map a network drive with: {user_smb_path}

3. Set host name
   - "sudo hostnamectl set-hostname <hostname>"
'''
        if self.args.user_email is not None:
            self._send_mail([self.args.user_email], subject, body, ip, dns_name)

    #@user_volume_az.setter
    #def user_volume_az(self, value):
     #   self._user_volume_az = value

def parse(args):
    parser = argparse.ArgumentParser(
        description='Create development environment in EE Cloud',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--user-id', required=True,
                        help='Intranet user id')
    parser.add_argument('--user-email', required=False,
                        help='User email address')
    parser.add_argument('--test-user-id', required=False,
                        help='Test user id that is used for instance and volume tagging')
    parser.add_argument('--os', required=False, default='fedora24',
                        help='Operating system to install. Can be image id (emi-12345678) or well reading name mapped at site.cfg')
    parser.add_argument('--instance-type', required=False, default='m1.small',
                        help='Instance type to create: {}'.format(' | '.join([
                            't1.micro=(1cpu 4500MB 25GB)',
                            'm1.small=(2cpu 8192MB 40GB)',
                            'm1.medium=(2cpu 15360MB 60GB)',
                            'c1.medium=(4cpu 15360MB 100GB)',
                            'm1.large=(4cpu 30720MB 200GB)'])))
    parser.add_argument('--volume-size', required=False, type=int, default=10,
                        help='User $HOME size in GB')
    parser.add_argument('--ansible-only', required=False, dest='ip',
                        help='IP for pre-created environment to configure (skips instance creation)'
                             'NOTE: Do NOT execute on live environments. This option is mostly for development work.')
    parser.add_argument('--base-image-only', required=False, action='store_true',
                        help='Flag to create base image that can be uploaded to EECloud for faster personal server creation')
    args = parser.parse_args(args)
    return args

def main(input_args):
    args = parse(input_args)
    CreateDev(args).run()

if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except EnvironmentCreateFailed:
        sys.exit(1)

        # Manual acceptance test list
        # - VNC desktop works
        # - ~/ can be mounted as network drive
        # - ddns name works
