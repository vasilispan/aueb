import argparse
import logging
import os
import re
import sys

from eucatools.exception import EECloudException
from eucatools.targetutils import TargetUtils
from eucatools.script.create_base import CreateBase
from eucatools.script.development_machine import settings
from ciutils.executor import ExecutionError

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))


class Batman(CreateBase):
    parts = ['os', 'instance_count', 'device_usage']

    def __init__(self, args):
        super(Batman, self).__init__(args)
        self.users = []
        self.user_data = {}

    @property
    def max_user_len(self):
        return len(max(self.users))

    def _set_data(self, user, key, data):
        if user not in self.user_data:
            self.user_data[user] = []
        self.user_data[user].append((key, data))
        logging.debug('Added: {}:{}:{}'.format(key, user, data))

    def _get_data(self, user):
        return self.user_data[user]

    def _get_data_strs(self, user):
        return ['{}: {}'.format(key, data) for key, data in self._get_data(user)]

    def run(self):
        try:
            self._run()
        except Exception as e:
            logging.critical(str(e))
            raise

    def _run(self):
        all_instances = self.e.describe_instances()
        self.instances = filter(self._is_development_machine, all_instances)
        self.users = sorted(set([i.user_name for i in self.instances]))

        steps_to_execute = []
        args = vars(self.args)
        if args.pop('test'):
            self.users = self.users[:2]
        if args.pop('all'):
            steps_to_execute += args.keys()
        else:
            for k,v in args.items():
                if v:
                    steps_to_execute.append(k)
        for step in steps_to_execute:
            self._log_title(step)
            getattr(self, '_read_' + step)()

        self._print_results()

    def _print_results(self):
        for u in self.users:
            data_strs = self._get_data_strs(u)
            # logging.info('{user:{width}}: {data}'.format(user=u, width=self.max_user_len, data=self._get_data_str(u)))
            logging.info('{user:{width}}: {data}'.format(user=u, width=self.max_user_len, data=data_strs[0]))
            for d in data_strs[1:]:
                logging.info('{user:{width}}  {data}'.format(user='', width=self.max_user_len, data=d))

    def _is_development_machine(self, instance):
        tag_pairs = [(t.key, t.value) for t in instance.tags]
        expected_tag = settings.tags.items()[0]
        if instance.user_name and expected_tag in tag_pairs:
            return True
        logging.debug('NOTE - not a development machine: {}'.format(instance))
        return False

    def _log_title(self, title):
        logging.info('Reading {}'.format(title))

    def _read_instance_count(self):
        for u in self.users:
            self._set_data(u, 'instance_count', len(self._get_user_instances(u)))

    def _get_user_instances(self, user):
        return [i for i in self.instances if i.user_name == user]

    def _read_cmd(self):
        for user in self.users:
            user_data = []
            for instance in self._get_user_instances(user):
                try:
                    r = TargetUtils(instance.ip, self.private_key).run_cmd(self.args.cmd)
                    out = r.stdout
                except ExecutionError:
                    out = 'execution FAILED'
                user_data += ['{}="{}"'.format(instance.id, out)]
            self._set_data(user, 'cmd_output', '[{}]'.format(', '.join(user_data)))

    def _read_device_usage(self):
        for u in self.users:
            blockdevice_data = []
            for i in self._get_user_instances(u):
                if not i.blockdevices:
                    instance_data = ['none']
                else:
                    instance_data = []
                    for b in i.blockdevices:
                        try:
                            r = TargetUtils(i.ip, self.private_key).run_cmd('df -h --output=source,size,pcent')
                            instance_data += [re.sub(' +', ' ', line)
                                              for line in r.stdout.splitlines() if b.device in line]
                        except ExecutionError:
                            instance_data += ['{} FAILED'.format(b.device)]
                blockdevice_data += ['{}={}'.format(i.id, ', '.join(instance_data))]
            self._set_data(u, 'blockdevice_usage', '[{}]'.format(', '.join(blockdevice_data)))

    def _read_os(self):
        for u in self.users:
            data = []
            for i in self._get_user_instances(u):
                try:
                    r = TargetUtils(i.ip, self.private_key).run_cmd('cat /etc/redhat-release')
                    match = re.match(r'(.*)\(', r.stdout.strip())
                    if match:
                        os = match.group(1)
                    else:
                        os = r.stdout.strip()
                except ExecutionError:
                    os = 'FAILED'
                data.append('{}={}({})'.format(i.id, os, i.image_id))
            self._set_data(u, 'os', '[{}]'.format(', '.join(data)))


def parse(args):
    parser = argparse.ArgumentParser(
        description='Create development environment in EE Cloud',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--all', required=False, action='store_true',
                        help='')
    parser.add_argument('--device-usage', required=False, action='store_true',
                        help='')
    parser.add_argument('--instance-count', required=False, action='store_true',
                        help='')
    parser.add_argument('--os', required=False, action='store_true',
                        help='')
    parser.add_argument('--cmd', required=False, help='')
    parser.add_argument('--test', required=False, action='store_true', help='')
    args = parser.parse_args(args)
    return args


def main(input_args):
    args = parse(input_args)
    Batman(args).run()


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except EECloudException:
        sys.exit(1)
