import argparse
import logging
import sys
import os

from ciutils.ansible import AnsibleRunner
from eucatools.exception import EECloudException
from eucatools.script.create_base import CreateBase
from eucatools.targetutils import TargetUtils
import settings


class CreateCI(CreateBase):
    def __init__(self, args):
        super(CreateCI, self).__init__(args)
        known_services = ['sonarqube', 'reviewboard']
        if self.args.service not in known_services:
            raise EECloudException('Unsupported service, known services: {}'.format(known_services))
        os.environ['http_proxy'] = self.http_proxy
        os.environ['https_proxy'] = self.http_proxy
        print os.environ['http_proxy']

    @property
    def settings(self):
        if hasattr(settings, self.args.service):
            return getattr(settings, self.args.service)
        return getattr(settings, 'default')

    @property
    def ee_tags(self):
        return {'ci_service': self.args.service}

    def _run(self):
        if self.args.ip:
            instance = self.e.describe_instance_by_ip(self.args.ip)
        else:
            instance = self._run_ee()
        self._run_ansible(instance.ip)
        logging.info('SHORT_DESCRIPTION: {} --> id:{} ip:{}'.format(self.args.name, instance.id, instance.ip))

    def _run_ee(self):
        instance = self._run_create_instance()
        TargetUtils(instance.ip, self.private_key).wait_instance_up(instance)
        volume = self._run_create_volume()
        self.e.attach_volume(instance.id, self.blockdevice, volume.id)
        return instance

    def _run_create_instance(self):
        instance = self.e.create_instance(
            name=self.args.name,
            image=self.resolve_image_id(self.settings['os']),
            instance_type=self.settings['instance_type'],
            tags=self.ee_tags,
            az=self.ee_az,
            pre_configured_key=self.ee_keypair_name,
            security_group=self.ee_security_group)
        return instance

    def _run_create_volume(self):
        return self.e.create_volume(
            self.ee_az,
            tags=self.ee_tags,
            name=self.args.name,
            size=self.settings['volume_size'],
            max_wait=40)

    def _run_ansible(self, ip):
        AnsibleRunner(ip, self.private_key).create_ci_service(self.args.service,
                                                              self.args.name,
                                                              self.admin_emails,
                                                              self.smtp_server,
                                                              self.args.remote_backup_target,
                                                              self.args.remote_backup_path)


def parse(args):
    parser = argparse.ArgumentParser(
        description='Create CI service in EE Cloud',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--service', required=True,
                        help='Service to deploy.'
                             'e.g. sonarqube')
    parser.add_argument('--name', required=True,
                        help='Name to use when naming EE Cloud instances and volumes. '
                             'Used also for setting up the host name of the instance. '
                             'e.g. sonarqube-test-1')
    parser.add_argument('--ansible-only', required=False, dest='ip',
                        help='IP of pre-created environment to configure (skips instance & volume creation).'
                             'NOTE: Do NOT execute on live environments. This option is mostly for development work.'
                             'e.g. 1.2.3.4')
    parser.add_argument('--remote-backup-target', default='localhost',
                        help='ssh target to store that backups '
                             'e.g. "user@1.2.3.4"')
    parser.add_argument('--remote-backup-path', default='/ephemeral/backups',
                        help='base path to store the backups '
                             'e.g. "/absolute/path" or "relative/path"')
    args = parser.parse_args(args)
    return args


def main(input_args):
    args = parse(input_args)
    CreateCI(args).run()


if __name__ == "__main__":
    main(sys.argv[1:])
