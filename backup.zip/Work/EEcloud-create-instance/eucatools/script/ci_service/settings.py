from copy import deepcopy

default = dict(instance_type='m1.small',
               volume_size=10,
               os='fedora23')

sonarqube = deepcopy(default)
sonarqube.update(dict(instance_type='m1.medium',
                      volume_size=10,
                      os='centos72'))

reviewboard = deepcopy(default)
reviewboard.update(dict(instance_type='m1.small',
                        volume_size=15,
                        os='centos72'))
