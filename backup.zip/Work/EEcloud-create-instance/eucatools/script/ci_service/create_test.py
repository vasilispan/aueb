import unittest

from mock import call
import mock

from eucatools.exception import EECloudException
from eucatools.script.ci_service import create
from eucatools.testutils.fake_site import get_default_config
from eucatools.testutils.validate import assert_calls

call_create_instance_sonar = call.create_instance(pre_configured_key='cloudman',
                                                  name='sonarqube-test-1',
                                                  tags={'ci_service': 'sonarqube'},
                                                  image='centos72',
                                                  instance_type='m1.medium',
                                                  security_group='default',
                                                  az='esclor86_2')
call_create_volume = call.create_volume('esclor86_2',
                                        max_wait=40,
                                        tags={'ci_service': 'sonarqube'},
                                        name='sonarqube-test-1',
                                        size=10)
fake_instance = mock.Mock()
fake_volume = mock.Mock()
call_attach_volume = call.attach_volume(fake_instance.id, '/dev/vdc', fake_volume.id)

call_ansible = call.create_ci_service('sonarqube', 'sonarqube-test-1', ['no.admin@configured'], 'mailrelay.int.nokia.com',
                                      'localhost', '/ephemeral/backups')


@mock.patch('eucatools.script.create_base.EucarcReader')
@mock.patch('eucatools.script.ci_service.create.TargetUtils')
@mock.patch('eucatools.script.ci_service.create.AnsibleRunner')
@mock.patch('eucatools.script.create_base.EucaUtils')
@mock.patch('__builtin__.open', create=True)
class DefaultBehaviourTest(unittest.TestCase):
    def test_create_unknown_service_fails(self, mock_site, mock_euca, mock_ansible, *_):
        mock_site.return_value.readline.side_effect = get_default_config()
        self.assertRaisesRegexp(EECloudException, r'^Unsupported service.*', create.main,
                                ['--service', 'unknown', '--name', 'whatever'])
        assert_calls(mock_euca.return_value.method_calls, [])
        assert_calls(mock_ansible.return_value.method_calls, [])

    def test_create(self, mock_site, mock_euca, mock_ansible, *_):
        mock_site.return_value.readline.side_effect = get_default_config()
        mock_euca.return_value.create_instance.side_effect = [fake_instance]
        mock_euca.return_value.create_volume.side_effect = [fake_volume]
        create.main(['--service', 'sonarqube', '--name', 'sonarqube-test-1'])
        expected_calls = [call_create_instance_sonar,
                          call_create_volume,
                          call_attach_volume]
        assert_calls(mock_euca.return_value.method_calls, expected_calls)
        assert_calls(mock_ansible.return_value.method_calls, [call_ansible])


if __name__ == "__main__":
    unittest.main()
