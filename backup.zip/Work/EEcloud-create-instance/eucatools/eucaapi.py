from ciutils.executor import Executor


class EucaApi(object):

    def __init__(self):
        self.e = Executor()

    def create_instance(self, image_id, instance_type, pre_configured_key, security_group, az, user_data=None):
        """
        instance types:
        t1.micro 1 cpu 4500 MB 25GB
        m1.small 2 cpu 8192 MB 40GB
        m1.medium 2 cpu 15360 MB 60GB
        c1.medium 4 cpu 15360 MB 100GB
        m1.large 4 cpu 30720 MB 200GB

        @image_id: e.g. emi-d7c3110f
        @instance_type: e.g. m1.small
        @pre_configured_key: e.g. cloudman
        @security_group: e.g. default
        @az: e.g. esclor84_1
        @user_data: e.g. /tmp/config
        """
        opts = []
        if user_data is not None:
            opts.append('-f {}'.format(user_data))
        cmd = 'euca-run-instances -g {sec} -k {key} -t {type} -z {az} {opts} {image}'.format(sec=security_group,
                                                                                             key=pre_configured_key,
                                                                                             type=instance_type,
                                                                                             az=az,
                                                                                             opts=' '.join(opts),
                                                                                             image=image_id)
        return self.e.run(cmd, retries=0)

    def describe_instances(self, ids=None):
        cmd = self._append_ids('euca-describe-instances', ids)
        return self.e.run(cmd, retries=3)

    def create_volume(self, az, size=None, snapshot_id=None):
        args = ''
        if size is not None:
            args += '-s {}'.format(size)
        if snapshot_id is not None:
            args += '--snapshot {}'.format(snapshot_id)
        cmd = 'euca-create-volume -z {} {}'.format(az, args)
        return self.e.run(cmd, retries=0)

    def describe_volumes(self, ids=None):
        cmd = self._append_ids('euca-describe-volumes', ids)
        return self.e.run(cmd, retries=3)

    def create_snapshot(self,  volume_id, description=None):
        args = ''
        if description is not None:
            args += '-d "{}" '.format(description)
        cmd = 'euca-create-snapshot {args}{volume_id}'.format(args=args, volume_id=volume_id)
        return self.e.run(cmd, retries=0)

    def delete_snapshot(self, snapshot_id):
        cmd = 'euca-delete-snapshot {}'.format(snapshot_id)
        return self.e.run(cmd, retries=3)

    def describe_snapshots(self, ids=None):
        cmd = self._append_ids('euca-describe-snapshots', ids)
        return self.e.run(cmd, retries=3)

    def attach_volume(self,  instance_id, device, volume_id):
        cmd = 'euca-attach-volume -i {} -d {} {}'.format(instance_id, device, volume_id)
        return self.e.run(cmd, retries=0)

    def detach_volume(self,  instance_id, volume_id):
        cmd = 'euca-detach-volume -i {} {}'.format(instance_id, volume_id)
        return self.e.run(cmd, retries=0)

    def _append_ids(self, cmd, ids):
        if ids is not None:
            return '{} {}'.format(cmd, ' '.join(ids))
        return cmd

    def create_tags(self, instance_id, tags):
        """
        @tags: dict e.g. {'key': 'value', 'key2': None}
        """
        tagstr = ''
        for key, value in tags.items():
            if value is None:
                tagstr += '--tag {} '.format(key)
            else:
                tagstr += '--tag {}={} '.format(key, value)
        cmd = 'euca-create-tags {}{}'.format(tagstr, instance_id)
        return self.e.run(cmd)
