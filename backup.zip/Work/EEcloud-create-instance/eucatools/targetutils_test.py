import unittest

import mock

from eucatools.targetutils import TargetUtils, WaitError
from eucatools.testutils.fake_object import create_fake_instance
from eucatools.testutils.fake_ssh_response import res_success, res_fail
from ciutils.executor import Executor


class CreateInstanceTest(unittest.TestCase):

    def setUp(self):
        pass

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, 'run')
    def test_ssh_success_immediate(self, mock_run, mock_sleep):
        mock_run.side_effect = [res_success,
                                res_success]
        TargetUtils('1.2.3.4').wait_instance_up(create_fake_instance(), max_wait=0)
        self.assertRegexpMatches(mock_run.call_args_list[0][0][0], 'ssh -q -o.*root@1.2.3.4 "uptime"')
        self.assertRegexpMatches(mock_run.call_args_list[1][0][0], 'ssh -q -o.*root@1.2.3.4 "test -f ~/ready"')
        self.assertEqual(mock_sleep.call_count, 0)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, 'run')
    def test_ssh_success_slow(self, mock_run, mock_sleep):
        mock_run.side_effect = [res_fail,
                                res_fail,
                                res_success,
                                res_success]
        TargetUtils('1.2.3.4').wait_instance_up(create_fake_instance(), max_wait=2, iter_wait=1)
        calls = mock_run.call_args_list
        self.assertEqual(len(calls), 4)
        self.assertEqual(mock_sleep.call_count, 2)

    @mock.patch('time.sleep')
    @mock.patch.object(Executor, 'run')
    def test_ssh_timeout(self, mock_run, mock_sleep):
        mock_run.side_effect = [res_fail,
                                res_fail,
                                res_fail]
        self.assertRaisesRegexp(
            WaitError, 'Timeout.*', TargetUtils('1.2.3.4').wait_instance_up, create_fake_instance(), max_wait=2, iter_wait=1)
        self.assertEqual(len(mock_run.call_args_list), 3)
        self.assertEqual(mock_sleep.call_count, 2)


if __name__ == "__main__":
    unittest.main()
