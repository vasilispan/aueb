import os

from ciutils.executor import Executor


class EucarcReader(object):

    def __init__(self, eucarc_path):
        self.eucarc = eucarc_path

    def source_eucarc(self):
        result = Executor().run('env -i bash -c ". {} && env"'.format(self.eucarc))
        for line in result.stdout.splitlines():
            (key, _, value) = line.partition("=")
            os.environ[key] = value
