import logging
import time


from ciutils.executor import Executor


class WaitError(Exception):
    pass


class TargetUtils(object):

    def __init__(self, ip, identity_file=None):
        self.e = Executor()
        self.ip = ip
        self.identity_file = identity_file

    def _ssh(self, cmd, raise_on_error=True, retries=0):
        if self.identity_file is not None:
            return self.e.ssh(self.ip, cmd,  identity_file=self.identity_file, raise_on_error=raise_on_error)
        return self.e.ssh(self.ip, cmd, raise_on_error=raise_on_error, retries=retries)

    def run_cmd(self, cmd, raise_on_error=True):
        result = self._ssh(cmd, raise_on_error=raise_on_error, retries=2)
        return result

    def wait_instance_up(self, instance, iter_wait=3, max_wait=120):
        self._wait(instance, "to be available via SSH", self._test_ssh_available, iter_wait, max_wait)
        self._wait(instance, "to complete user data", self._test_user_data_processed, iter_wait, max_wait)

    def _wait(self, instance, what, method, iter_wait=3, max_wait=120):
        result = method()
        what = 'waiting instance {}'.format(what)
        logging.info('{}: {}'.format(what, instance))
        tot_wait = 0
        while result.status != 0:
            if tot_wait >= max_wait:
                raise WaitError('Timeout {}sec reached while {} ({})'.format(max_wait, what, instance))
            logging.debug(
                "Not yet ready: {}: {} (waiting {}/{})".format(what, result.status, tot_wait, max_wait))
            time.sleep(iter_wait)
            tot_wait += iter_wait
            result = method()
        logging.info("Complete: {}: {} (waiting {}/{})".format(what, instance, tot_wait, max_wait))

    def _test_ssh_available(self):
        return self._ssh('uptime', raise_on_error=False)

    def _test_user_data_processed(self):
        return self._ssh('test -f ~/ready', raise_on_error=False)
