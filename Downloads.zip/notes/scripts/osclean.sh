#!/usr/bin/env bash
#!/bin/env bash
#!/bin/bash

read -p 'clean controller! continue with caution..'

. keystonerc_admin

ADMIN_TENANT_ID=$(keystone tenant-list |grep admin | cut -d\  -f2)
SERVICES_TENANT_ID=$(keystone tenant-list |grep services | cut -d\  -f2)



read -p 'release all floating ips..'
neutron floatingip-list |grep '10.' |cut -d\  -f2 | xargs -I {} neutron floatingip-delete {}



read -p "clean stacks (and floatingips) from cloudtaf's tenants.."
. keystonerc_admin ; TENANTS_IDS=$(keystone tenant-list  | grep ctafDyn | cut -d\  -f4 | sed 's/ctafDynTenant//') ; export OS_PASSWORD=tenant_pass
for ID in $TENANTS_IDS
do
echo ctafDynXXX$ID
unset OS_SERVICE_TOKEN OS_SERVICE_ENDPOINT
export OS_USERNAME=ctafDynUser$ID
export OS_TENANT_NAME=ctafDynTenant$ID
glance image-delete $(glance image-list | grep CIU_vgp_ | cut -f4 -d' ')
neutron floatingip-list |grep '10.' |cut -d\  -f2 | xargs -I {} neutron floatingip-delete {}
heat stack-list | grep ci-deployer | cut -f2 -d' ' | xargs -I {} heat stack-delete {}
done
. keystonerc_admin



read -p 'delete also these tenants (wait a bit to be sure that stacks are actually deleted) ...'
. keystonerc_admin
keystone user-list | grep 'ctafDynUser' | cut -d' ' -f2 | xargs -I {} keystone user-delete {}
keystone tenant-list | grep 'ctafDynTenant' | cut -d' ' -f2 | xargs -I {} keystone tenant-delete {}
rm -f tkey*.priv




read -p 'create tenants which are not visible anymore and delete their stacks..'
VISIBLE_TENANTS_IDS="$(keystone tenant-list |grep -v 'id' | grep '|' | cut -d\  -f2)"
DB_TENANTS_IDS=$((mysql | grep tenant_id | cut -d\  -f2)  <<'EOF'
SET NAMES 'utf8' COLLATE 'utf8_general_ci';
select distinct(tenant_id) from (
(select tenant_id from neutron.routers) 
union 
(select tenant_id from neutron.ports) 
union 
(select project_id COLLATE 'utf8_general_ci' as tenant_id from nova.instances where vm_state != 'deleted') 
union 
(select owner as tenant_id from glance.images where deleted = 0 and name like 'CIU_vgp_%')
) as res \G;
quit
EOF)
#--union (select user_id as tenant_id from cinder.volumes where attached_status != 'detached')

NONEXISTS_TENANTS_IDS="$(grep -Fxv -f <(echo -n -e $VISIBLE_TENANTS_IDS | tr ' ' '\n' ) <(echo -n -e $DB_TENANTS_IDS | tr ' ' '\n'))"
. keystonerc_admin
N=0
for ID in $NONEXISTS_TENANTS_IDS
do
echo "Trush tenant ID: $ID"
tenant_id=$ID
let N+=1 ;
TENANT_NAME="ctafDynTenant-$N"
USER_NAME="ctafDynUser-$N"
keystone tenant-create --name $TENANT_NAME --description "ShortLive Tenant"
#change the tenant id to db:
## -- select id, name from keystone.project where name = "${TENANT_NAME}" \G;
mysql <<EOF
update keystone.project set id = "${tenant_id}" where name = "${TENANT_NAME}";
quit
EOF

#create user:
keystone user-create --name $USER_NAME --tenant $tenant_id --pass tenant_pass
#add the usual roles:
user_id=$(keystone user-list | grep $USER_NAME | cut -d' ' -f2)
keystone user-role-list --tenant ${tenant_id} --user ${user_id}
keystone user-role-add --user $user_id --tenant $tenant_id --role $(keystone role-list | grep heat_stack_owner | cut -d' ' -f2)

#create a key:
unset OS_SERVICE_TOKEN OS_SERVICE_ENDPOINT
export OS_PASSWORD=tenant_pass
export OS_USERNAME="$USER_NAME"
export OS_TENANT_NAME="$TENANT_NAME"
nova keypair-add "tkey$N" > "tkey$N.priv"
. keystonerc_admin
done



read -p "delete the new tenant's (old) stacks.."
. keystonerc_admin ; TENANTS_IDS=$(keystone tenant-list  | grep ctafDyn | cut -d\  -f4 | sed 's/ctafDynTenant//') ; export OS_PASSWORD=tenant_pass
for ID in $TENANTS_IDS
do
echo ctafDynXXX$ID
unset OS_SERVICE_TOKEN OS_SERVICE_ENDPOINT
export OS_USERNAME=ctafDynUser$ID
export OS_TENANT_NAME=ctafDynTenant$ID
glance image-delete $(glance image-list | grep CIU_vgp_ | cut -f4 -d' ')
neutron floatingip-list |grep '10.' |cut -d\  -f2 | xargs -I {} neutron floatingip-delete {}
heat stack-list | grep ci-deployer | cut -f2 -d' ' | xargs -I {} heat stack-delete {}
done
. keystonerc_admin



read -p 'delete also these new tenants (wait a bit to be sure that stacks are actually deleted) ...'
. keystonerc_admin
keystone user-list | grep 'ctafDynUser' | cut -d' ' -f2 | xargs -I {} keystone user-delete {}
keystone tenant-list | grep 'ctafDynTenant' | cut -d' ' -f2 | xargs -I {} keystone tenant-delete {}
rm -f tkey*.priv


