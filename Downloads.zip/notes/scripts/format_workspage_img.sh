#!/bin/bash

echo "Inside format_workspage_img.sh!!!"

if [ ! -b /dev/vdb ];then
  echo "No vdb device found. Check if you have added correct workspace qcow2 image while starting VM!!"
  exit 1
fi

echo "*************************************"
echo "Partition tabel before Pratitioning."
echo "*************************************"
fdisk -l

echo "Creating primary partition."
fdisk /dev/vdb <<EOF
o
n
p
1


w
q
EOF

echo "*************************************"
echo "Partition tabel after Pratitioning."
echo "*************************************"
fdisk -l

echo "Formatting filesystem."
mkfs.ext4 /dev/vdb1 -L "workspace"
mkdir -p /var/workspace
mount /dev/vdb1 /var/workspace

# Add an entry in fstab for the above mount during reboot of VM.
echo "/dev/vdb1    /var/workspace   ext4  rw  0  0" >> /etc/fstab

echo "*************************************"
echo "Finished executing format_workspace_img.sh. Exiting now! "
echo "*************************************"

