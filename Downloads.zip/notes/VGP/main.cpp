#include <unistd.h>
#include <string.h>
#include <iostream>
#include <stdexcept>
#include <sys/wait.h>

int main() {
    int fds[2];
    pipe(fds);

    pid_t pid = fork();

    if (pid < 0) {
        std::cout << "Failed to fork" << std::endl;
        throw std::runtime_error("Failed to fork");
    } else if (pid == 0) {
        // child
        close(fds[0]);
        dup2(fds[1], STDOUT_FILENO);
        char* argv[] = {"/bin/lsaaa", "-l", "/dummy/path", NULL};
        execve(argv[0], argv, environ);
        std::cout << "Could not find binary";
    } else {
        // parent
        close(fds[1]);
        char buffer[100] = {0};
        while (true) {
            memset(buffer, 0, sizeof(buffer));
            int n = read(fds[0], buffer, sizeof(buffer)-1);
            if (n)
                std::cout << buffer;
            else
                break;
        }

        int returnStatus;
        waitpid(pid, &returnStatus, 0);
        std::cout << "return code: " << returnStatus << std::endl;
    }
}
