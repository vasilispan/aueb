#!/bin/bash 
PREFIX=${1-'FT_'}
NEW_PREFIX=${2-'VGP_MI_'}
for filetype in d f
do
   for x in $( find .  -type $filetype -name "$PREFIX*" )
   do
       y=$( basename $x  )
       t=$( dirname ${x} )
       if [ ${y:0:${#PREFIX}} == "$PREFIX" ]
       then 
           mv -v  $x "$t/$NEW_PREFIX${y:${#PREFIX}}"
       fi
   done
done

