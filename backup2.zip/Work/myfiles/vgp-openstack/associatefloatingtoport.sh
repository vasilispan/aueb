#!/bin/bash

stack_name=$1
stack_list=$( heat stack-list | awk '{print $4}')
if [[ "$stack_list" == *"$stack_name"* ]]; then
    echo -e "\nStack name checks out. Begin procedure.\n"
else
    echo -e "\nStack name invalid. Abort procedure."
    exit 1
fi

#get floating ip ID
floatingid=$( neutron floatingip-create publicExtNet | grep -m2 id | tail -n1 | cut -d '|' -f 3)

#get port ID
port=$( neutron port-list | grep $stack_name |  grep NE3S | cut -d '|' -f 2)

fixedip=$( neutron port-list | grep $stack_name | grep -i ne3s | cut -d ',' -f2 | cut -d ':' -f2 | sed 's/"//g' | tr -d '}' | tr -d '|' | sed 's/ //g')
echo -e 'Use fsclish commands to assign NE3SAgent to this fixed address: '$fixedip'\n'
echo -e "fsclish command: add networking address /Ne3sAgent iface management ip-address $fixedip/24\n"

neutron floatingip-associate $floatingid $port &> /dev/null

#find floating associated to port
floatingip=$( neutron floatingip-list | grep "$port" | cut -d '|' -f 4)
echo -e 'Floating Ip address for NE3S RG is '$floatingip'\n'

