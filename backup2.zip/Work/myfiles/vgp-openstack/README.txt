this is vgp-ncio stuff
